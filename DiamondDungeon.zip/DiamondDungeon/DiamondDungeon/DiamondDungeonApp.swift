//
//  DiamondDungeonApp.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/26/20.
//

import SwiftUI

@main

struct DiamondDungeonApp: App {
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false
    
    var body: some Scene {
        WindowGroup {
            ActiveScreen()
        }
    }
}
