//
//  TileSetTwentyFour.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/7/21.
//

import SwiftUI

struct TileSetTwentyFour: View {
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("TutPart2") var TutPart2 = false
    
    @AppStorage ("WallCracked") var WallCracked = false
    @AppStorage ("BombEquipped") var BombEquipped = false
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
    
    @AppStorage ("TutorialComplete") var TutorialComplete = false
    
    var body: some View {
        if TutPart2 == true {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
            ZStack{
                if WallCracked == false {
                    CheckWallType()
                } else if WallCracked == true {
                    Image("Floor.Stone")
                        .resizable()
                            .foregroundColor(Color(red: 94/255, green: 64/255, blue: 51/255))
                        .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                }
                if CharacterPlacement == 2{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                }
            }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                    CheckWallType()

                     
                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        Image("Floor.Stone")
                            .resizable()
                            .foregroundColor(Color.white)
                        .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                    if CharacterPlacement == 4{
                        Image("Hero.TDV")
                            .rotationEffect(.degrees(90))
                            .scaleEffect(1.5)
                    }
                }
            
            //TILE #5 (MIDDLE, MIDDLE)
            ZStack{
                Image("Floor.Stone")
                .resizable()
                        .foregroundColor(Color.white)
                    .aspectRatio(contentMode: .fit)
                    .edgesIgnoringSafeArea(.all)
                        .cornerRadius(5)
                if CharacterPlacement != 5 && BombEquipped == false {
                    Image("Game.Bomb")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .scaleEffect(0.7)
                }
                if CharacterPlacement == 5 {
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                        .rotationEffect(.degrees(90))
                    }
                }
            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        Image("Floor.Stone")
                            .resizable()
                                .foregroundColor(Color.white)
                            .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .rotationEffect(.degrees(90))
                                .scaleEffect(1.5)
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                   
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 8{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                    
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    CheckWallType()

                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                        
                                }
                            }
                        }
        } else if TutPart2 == false {
            
            ZStack {
                VStack {
                    
            HStack{
                //TILE #1 (TOP LEFT CORNER)
                    ZStack{
                        CheckWallType()
                    if CharacterPlacement == 1{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                        }
                    }
                //TILE #2 (TOP MIDDLE)
                ZStack{
                    if WallCracked == false {
                    Image("Wall.CobblestoneCracked")
                        .resizable()
                            .foregroundColor(Color(red: 94/255, green: 64/255, blue: 51/255))
                        .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                    } else if WallCracked == true {
                        Image("Floor.Stone")
                            .resizable()
                                .foregroundColor(Color(red: 94/255, green: 64/255, blue: 51/255))
                            .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                                .cornerRadius(5)
                    }
                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
                //TILE #3 (TOP RIGHT CORNER)
                    ZStack{
                        CheckWallType()
                         
                        if CharacterPlacement == 3{
                            Image("Hero.TDV")
                                .scaleEffect(1.5)
                        }
                    }
            }
            HStack{
                //TILE #4 (MIDDLE LEFT SIDE)
                        ZStack{
                            Image("Floor.Stone")
                                .resizable()
                                .foregroundColor(Color.white)
                            .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                                .cornerRadius(5)
                        if CharacterPlacement == 4{
                            Image("Hero.TDV")
                                .rotationEffect(.degrees(90))
                                .scaleEffect(1.5)
                        }
                    }
                
                //TILE #5 (MIDDLE, MIDDLE)
                ZStack{
                    Image("Floor.Stone")
                    .resizable()
                            .foregroundColor(Color.white)
                        .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                    if CharacterPlacement != 5 && BombEquipped == false {
                        Image("Game.Bomb")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .scaleEffect(0.7)
                    }
                    if CharacterPlacement == 5 {
                        CharacterDirection()
                        
                        }
                    }
                //TILE #6 (MIDDLE RIGHT SIDE)
                        ZStack{
                            Image("Floor.Stone")
                                .resizable()
                                    .foregroundColor(Color.white)
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .cornerRadius(5)
                            if CharacterPlacement == 6{
                                Image("Hero.TDV")
                                    .rotationEffect(.degrees(90))
                                    .scaleEffect(1.5)
                                }
                            }
                        }
                HStack{
                    //TILE #7 (BOTTOM LEFT SIDE)
                                ZStack{
                                    CheckWallType()
                                if CharacterPlacement == 7{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                       
                                }
                            }
                    //TILE #8 (MIDDLE BOTTOM SIDE)
                                ZStack{
                                    CheckWallType()
                                if CharacterPlacement == 8{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                        
                                    }
                                }
                    //TILE #9 (BOTTOM RIGHT CORNER)
                                    ZStack{
                                        CheckWallType()
                                    if CharacterPlacement == 9{
                                        Image("Hero.TDV")
                                            .scaleEffect(1.5)
                                            
                                    }
                                }
                            }
                }
            ZStack{
            Image("Comment.Box")
                .resizable()
            VStack {
        Text("Collecting Items Will Move")
            .font(.system(size: 14))
            .bold()
        Text("Them To The Top Area  ")
            .font(.system(size: 14))
            .bold()
        Text("Collect Items By Walking Over Them   ")
            .font(.system(size: 14))
            .bold()
            Text("                                  ")
            Text("                                  ")
            Text("                                  ")
            Text("                                  ")
                    }
                }
            }
        }
            Spacer__()
    }
}

struct TileSetTwentyFour_Previews: PreviewProvider {
    static var previews: some View {
        TileSetTwentyFour()
    }
}
