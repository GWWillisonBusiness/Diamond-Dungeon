//
//  TileSetTwentyFive.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/7/21.
//

import SwiftUI

struct TileSetTwentyFive: View {
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 8
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("CurrentEnemyHealth") var CurrentEnemyHealth = 4
    @AppStorage ("CurrentEnemyAttack") var CurrentEnemyAttack = 2
    
    @AppStorage ("EnemyValue") var EnemyValue = Int.random(in: 1..<4)
    @AppStorage ("EnemyHasBeenChosen") var EnemyHasBeenChosen = false
    @AppStorage ("EnemyLevel") var EnemyLevel = 1
    @AppStorage ("EnemyDefeated7") var EnemyDefeated7 = 0
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
    
    @AppStorage ("TutorialComplete") var TutorialComplete = false
    
    var body: some View {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
                ZStack{
                    CheckWallType()

                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                            
                    }
                }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                        CheckWallType()

                     
                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        Image("Floor.Stone")
                            .resizable()
                            .foregroundColor(Color.white)
                        .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                    if CharacterPlacement == 4{
                        Image("Hero.TDV")
                            .rotationEffect(.degrees(90))
                            .scaleEffect(1.5)
                    }
                }
            
            //TILE #5 (MIDDLE, MIDDLE)
        ZStack{
            if CharacterPlacement != 5 {
                Image("Floor.Stone")
                    .resizable()
                    .foregroundColor(Color.white)
                .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                    .cornerRadius(5)
                if EnemyDefeated7 == 0 {
                if EnemyLevel == 1 {
                    Image("Enemy.NightBat")
                }
                if EnemyLevel == 2 {
                    Image("Enemy.GreenGhost")
                }
                if EnemyLevel == 3 {
                    Image("Enemy.SmallRedBlob")
                    }
                }
            } else if CharacterPlacement == 5 {
                if CharacterPlacement == 5 && EnemyDefeated7 == 0 {
                       ZStack{
                        Image("Floor.Stone")
                        .resizable()
                               .foregroundColor(Color.white)
                               .frame(width: 2000, height: 2000)
                        Rectangle()
                            .frame(width: 1000, height: 5)
                           VStack {
                               Text(" ENEMY ")
                                   .bold()
                                   .foregroundColor(Color.black)
                                   .font(.system(size: 42))
                               Text("Level: " + String(EnemyLevel))
                   

                            Button(action: {
                                
                                
                                
                                if EnemyLevel == 1 {
                                 
                                    CurrentEnemyAttack = 1
                                    CurrentEnemyHealth = 3
                                } else if EnemyLevel == 2 {
                             
                                    CurrentEnemyAttack = 2
                                    CurrentEnemyHealth = 5
                                } else if EnemyLevel == 3 {
                                    
                                    CurrentEnemyAttack = 3
                                    CurrentEnemyHealth = 8
                                }
                                
                                CurrentScreen = 9
                                EnemyDefeated7 = 1
                            }) {
                               ZStack{
                                       Circle()
                                           //.font(.system(size: 42))
                                           .foregroundColor(Color.red)
                                           .padding(.all, 20)
                                           .frame(width: 200, height: 200)

                                 
                                     Text("FIGHT")
                                       .bold()
                                       .foregroundColor(Color.white)
                                       .font(.system(size: 42))
                               }
                                      
                                           }
                               Text(" YOU ")
                                   .bold()
                                   .foregroundColor(Color.black)
                                   .font(.system(size: 42))
                               Text("Level: 1") // Add Level var
                                   .bold()
                                   } //VStack
                           }
                       } else if CharacterPlacement != 5 && EnemyDefeated7 == 0 {
                           if EnemyLevel == 1 {
                               Image("Enemy.NightBat")
                           } else if EnemyLevel == 2 {
                               Image("Enemy.GreenGhost")
                           } else if EnemyLevel == 3 {
                               Image("Enemy.SmallRedBlob")
                           }
                       } else if CharacterPlacement == 5 && EnemyDefeated7 == 2 {
                           ZStack{
                            Image("Floor.Stone")
                                .resizable()
                                   .foregroundColor(Color.white)
                               .aspectRatio(contentMode: .fit)
                               .edgesIgnoringSafeArea(.all)
                                   .cornerRadius(5)
                               
                               CharacterDirection()
                               
                           }
                       } else if CharacterPlacement == 5 && EnemyDefeated7 == 1 {
                           ZStack{
                            Image("Floor.Stone")
                                .resizable()
                                   .foregroundColor(Color.white)
                               .aspectRatio(contentMode: .fit)
                               .edgesIgnoringSafeArea(.all)
                                   .cornerRadius(5)

                               CharacterDirection()

                           }
                       }
                   }
            }
            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        Image("Floor.Stone")
                            .resizable()
                                .foregroundColor(Color.white)
                            .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .rotationEffect(.degrees(90))
                                .scaleEffect(1.5)
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                   
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 8{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                    
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    CheckWallType()

                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                        
                                }
                            }
                        }
            Spacer__()
    }
}

struct TileSetTwentyFive_Previews: PreviewProvider {
    static var previews: some View {
        TileSetTwentyFive()
    }
}
