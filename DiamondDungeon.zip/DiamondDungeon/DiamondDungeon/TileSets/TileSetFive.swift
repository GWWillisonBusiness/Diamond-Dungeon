//
//  TileSetFive.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/29/20.
//
// B G B
// G G B
// B B B

import SwiftUI

struct TileSetFive: View {
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    @AppStorage ("EnemyValue") var EnemyValue = Int.random(in: 1..<4)
    @AppStorage ("EnemyHasBeenChosen") var EnemyHasBeenChosen = false
    @AppStorage ("EnemyLevel") var EnemyLevel = 1
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 8
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("CurrentEnemyHealth") var CurrentEnemyHealth = 4
    @AppStorage ("CurrentEnemyAttack") var CurrentEnemyAttack = 2

    @AppStorage ("EC") var EnemyChosen = Int.random(in: 1..<4)

    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
    
    var body: some View {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
                ZStack{
                    CheckFloorType()

                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                    CheckWallType()

                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        CheckFloorType()

                    if CharacterPlacement == 4{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                            .rotationEffect(.degrees(90))
                    }
                }
            
            
                //TILE #5 (MIDDLE, MIDDLE)
            ZStack{
                if CharacterPlacement != 5 {
                    
                    CheckFloorType()
                    
                    if EnemyDefeated4 == 0 {
                    if EnemyLevel == 1 {
                        Image("Enemy.NightBat")
                    }
                    if EnemyLevel == 2 {
                        Image("Enemy.GreenGhost")
                    }
                    if EnemyLevel == 3 {
                        Image("Enemy.SmallRedBlob")
                        }
                    }
                } else if CharacterPlacement == 5 {
                    if CharacterPlacement == 5 && EnemyDefeated4 == 0 {
                           ZStack{
                            
                          CheckFloorEnemy()

                            Rectangle()
                                .frame(width: 1000, height: 5)
                               VStack {
                                   Text(" ENEMY ")
                                       .bold()
                                       .foregroundColor(Color.black)
                                       .font(.system(size: 42))
                                   Text("Level: " + String(EnemyLevel))
                       

                                Button(action: {
                                    
                                    
                                    
                                    if EnemyLevel == 1 {
                                     
                                        CurrentEnemyAttack = 1
                                        CurrentEnemyHealth = 3
                                    } else if EnemyLevel == 2 {
                                 
                                        CurrentEnemyAttack = 2
                                        CurrentEnemyHealth = 5
                                    } else if EnemyLevel == 3 {
                                        
                                        CurrentEnemyAttack = 3
                                        CurrentEnemyHealth = 8
                                    }
                                    
                                    CurrentScreen = 9
                                    EnemyDefeated4 = 1
                                }) {
                                   ZStack{
                                           Circle()
                                               //.font(.system(size: 42))
                                               .foregroundColor(Color.red)
                                               .padding(.all, 20)
                                               .frame(width: 200, height: 200)

                                     
                                         Text("FIGHT")
                                           .bold()
                                           .foregroundColor(Color.white)
                                           .font(.system(size: 42))
                                   }
                                          
                                               }
                                   Text(" YOU ")
                                       .bold()
                                       .foregroundColor(Color.black)
                                       .font(.system(size: 42))
                                   Text("Level: " + String(EnemyLevel)) // Add Level var
                                       } //VStack
                               }
                           } else if CharacterPlacement != 5 && EnemyDefeated4 == 0 {
                               if EnemyLevel == 1 {
                                   Image("Enemy.NightBat")
                               } else if EnemyLevel == 2 {
                                   Image("Enemy.GreenGhost")
                               } else if EnemyLevel == 3 {
                                   Image("Enemy.SmallRedBlob")
                               }
                           } else if CharacterPlacement == 5 && EnemyDefeated4 == 2 {
                               ZStack{
                                
                                CheckFloorType()

                                   
                                   CharacterDirection()
                                   
                               }
                           } else if CharacterPlacement == 5 && EnemyDefeated4 == 1 {
                               ZStack{
                              CheckFloorType()


                                   CharacterDirection()

                               }
                           }
                       }
                }
            

            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        CheckWallType()

                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .scaleEffect(1.5)
                                .rotationEffect(.degrees(90))
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 8{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    CheckWallType()

                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                }
                            }
                        }
            Spacer__()
    }
}

struct TileSetFive_Previews: PreviewProvider {
    static var previews: some View {
        TileSetFive()
    }
}
