//
//  TileSetFour.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/29/20.
//
// B B B
// W G W
// B G B

import SwiftUI

struct TileSetFour: View {
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
    
    var body: some View {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
                ZStack{
                    CheckWallType()

                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                    CheckWallType()
                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        CheckFloorType3()

                    if CharacterPlacement == 4{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                            .rotationEffect(.degrees(90))
                    }
                }
            
            //TILE #5 (MIDDLE, MIDDLE)
                    ZStack{
                        CheckFloorType2()

                        if CharacterPlacement == 5{
                            CharacterDirection()
                            
                        }
                    }
            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        CheckFloorType3()

                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .scaleEffect(1.5)
                                .rotationEffect(.degrees(90))
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckFloorType3()
                            if CharacterPlacement == 8{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    CheckWallType()
                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                }
                            }
                        }
            Spacer__()
    }
}


struct TileSetFour_Previews: PreviewProvider {
    static var previews: some View {
        TileSetFour()
    }
}
