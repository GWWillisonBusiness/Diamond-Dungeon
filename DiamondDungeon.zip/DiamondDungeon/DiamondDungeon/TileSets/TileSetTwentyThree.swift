//
//  TileSetTwentyThree.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/7/21.
//

import SwiftUI

struct TileSetTwentyThree: View {
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("TutPart1") var TutPart1 = false
    @AppStorage ("TutorialComplete") var TutorialComplete = false
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
    
    
    var body: some View {
        if TutPart1 == false {
        ZStack {
            VStack {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
                ZStack{
                    CheckWallType()

                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                            
                    }
                }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                    CheckWallType()

                     
                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        CheckWallType()

                    if CharacterPlacement == 4{
                        Image("Hero.TDV")
                            .rotationEffect(.degrees(90))
                            .scaleEffect(1.5)
                    }
                }
            
            //TILE #5 (MIDDLE, MIDDLE)
                    ZStack{
                        if TutorialComplete == false {
                        Image("Floor.Stone")
                            .resizable()
                                .foregroundColor(Color.white)
                            .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                        } else if TutorialComplete == true {
                            CheckFloorType()
                        }
                        if CharacterPlacement == 5{
                            
                            CharacterDirection()
                        }
                    }
            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        if TutorialComplete == false {
                        Image("Floor.Stone")
                            .resizable()
                                .foregroundColor(Color.white)
                            .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                        } else if TutorialComplete == true {
                            CheckFloorType()
                        }
                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .rotationEffect(.degrees(90))
                                .scaleEffect(1.5)
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                   
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckWallType()
                            if CharacterPlacement == 8{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                    
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    
                                    CheckWallType()
                                    
                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                        
                                }
                            }
                        }
                    }
            if TutorialComplete == false && TutPart1 == false {
            Image("Comment.Box")
                .scaleEffect(1.0001)
                
                VStack {
            Text("Welcome! Start By Using   ")
                .font(.system(size: 25))
                .bold()
            Text("The Arrows Keys To Move.  ")
                .font(.system(size: 25))
                .bold()
            Text("                        ")
            Text("                        ")
            Text("                        ")
            Text("                        ")
            Text("                        ")
            Text("                        ")
                    }
                
            }
        }
        } else if TutPart1 == true {
            
                
            HStack{
                //TILE #1 (TOP LEFT CORNER)
                    ZStack{
                        CheckWallType()

                    if CharacterPlacement == 1{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                        }
                    }
                //TILE #2 (TOP MIDDLE)
                    ZStack{
                        CheckWallType()
                        if CharacterPlacement == 2{
                            Image("Hero.TDV")
                                .scaleEffect(1.5)
                                
                        }
                    }
                //TILE #3 (TOP RIGHT CORNER)
                    ZStack{
                        CheckWallType()

                        if CharacterPlacement == 3{
                            Image("Hero.TDV")
                                .scaleEffect(1.5)
                        }
                    }
            }
            HStack{
                //TILE #4 (MIDDLE LEFT SIDE)
                        ZStack{
                            CheckWallType()

                        if CharacterPlacement == 4{
                            Image("Hero.TDV")
                                .rotationEffect(.degrees(90))
                                .scaleEffect(1.5)
                        }
                    }
                
                //TILE #5 (MIDDLE, MIDDLE)
                        ZStack{
                            if TutorialComplete == false {
                            Image("Floor.Stone")
                                .resizable()
                                    .foregroundColor(Color.white)
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .cornerRadius(5)
                            } else if TutorialComplete == true {
                                CheckFloorType()
                            }
                            if CharacterPlacement == 5{
                                
                                CharacterDirection()
                            }
                        }
                //TILE #6 (MIDDLE RIGHT SIDE)
                        ZStack{
                            if TutorialComplete == false {
                            Image("Floor.Stone")
                                .resizable()
                                    .foregroundColor(Color.white)
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .cornerRadius(5)
                            } else if TutorialComplete == true {
                                CheckFloorType()
                            }
                            if CharacterPlacement == 6{
                                Image("Hero.TDV")
                                    .rotationEffect(.degrees(90))
                                    .scaleEffect(1.5)
                                }
                            }
                        }
                HStack{
                    //TILE #7 (BOTTOM LEFT SIDE)
                                ZStack{
                                    CheckWallType()

                                if CharacterPlacement == 7{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                       
                                }
                            }
                    //TILE #8 (MIDDLE BOTTOM SIDE)
                                ZStack{
                                    CheckWallType()

                                if CharacterPlacement == 8{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                        
                                    }
                                }
                    //TILE #9 (BOTTOM RIGHT CORNER)
                                    ZStack{
                                        CheckWallType()

                                    if CharacterPlacement == 9{
                                        Image("Hero.TDV")
                                            .scaleEffect(1.5)
                                            
                                    }
                                }
                            }
                        
        }
            Spacer__()
    }
}

struct TileSetTwentyThree_Previews: PreviewProvider {
    static var previews: some View {
        TileSetTwentyThree()
    }
}
