//
//  TileSetNineteen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 2/15/21.


import SwiftUI

struct TileSetNineteen: View {
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("BombEquipped") var BombEquipped = false
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("trophyGain") var trophyGain = Int.random(in: 3..<11)
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
        
    //System of Currency
    @AppStorage ("Coin")    var Coins = 0
    @AppStorage ("Diamond")  var Diamond = 0
    @AppStorage ("Trophy")  var Trophy = 0
    
    //Map Active ( 0 = False) (1 = True)
    @AppStorage ("MapActive") var MapActive = 0
    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
        
    var body: some View {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
                ZStack{
                    CheckWallType()

                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                    CheckWallType()
                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        CheckWallType()

                    if CharacterPlacement == 4 {
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                            .rotationEffect(.degrees(90))
                    }
                }
            
            //TILE #5 (MIDDLE, MIDDLE)
            ZStack{
                CheckFloorType()
                if CharacterPlacement != 5 && BombEquipped == false {
                    Image("Game.Bomb")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .scaleEffect(0.7)
                }
                if CharacterPlacement == 5 {
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                        .rotationEffect(.degrees(90))
                    }
                }
                    
            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        CheckFloorType()
                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .scaleEffect(1.5)
                                .rotationEffect(.degrees(90))
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 8{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    CheckWallType()

                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                }
                                  
                            }
                        }
            Spacer__()
        }
    }


struct TileSetNineteen_Previews: PreviewProvider {
    static var previews: some View {
        TileSetNineteen()
    }
}
