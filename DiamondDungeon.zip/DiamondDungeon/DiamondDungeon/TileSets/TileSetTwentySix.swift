//
//  TileSetTwentySix.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/7/21.
//

import SwiftUI

struct TileSetTwentySix: View {
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("TutorialComplete") var TutorialComplete = false
    @AppStorage ("trophyGain") var trophyGain = 10
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
        
    //System of Currency
    @AppStorage ("Coin")    var Coins = 0
    @AppStorage ("Diamond")  var Diamond = 0
    @AppStorage ("Trophy")  var Trophy = 0
    
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 10
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false

    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var leftBoardEdge = 0
    @AppStorage ("rightBoardEdge") var rightBoardEdge = 0
    @AppStorage ("topBoardEdge") var topBoardEdge = 0
    @AppStorage ("bottomBoardEdge") var downBoardEdge = 0
    
    
    var body: some View {
        HStack{
            //TILE #1 (TOP LEFT CORNER)
                ZStack{
                    CheckWallType()

                if CharacterPlacement == 1{
                    Image("Hero.TDV")
                        .scaleEffect(1.5)
                    }
                }
            //TILE #2 (TOP MIDDLE)
                ZStack{
                    CheckWallType()

                    if CharacterPlacement == 2{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                            
                    }
                }
            //TILE #3 (TOP RIGHT CORNER)
                ZStack{
                    CheckWallType()

                     
                    if CharacterPlacement == 3{
                        Image("Hero.TDV")
                            .scaleEffect(1.5)
                    }
                }
        }
        HStack{
            //TILE #4 (MIDDLE LEFT SIDE)
                    ZStack{
                        Image("Floor.Stone")
                            .resizable()
                            .foregroundColor(Color.white)
                        .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                            .cornerRadius(5)
                    if CharacterPlacement == 4{
                        Image("Hero.TDV")
                            .rotationEffect(.degrees(90))
                            .scaleEffect(1.5)
                    }
                }
            
            //TILE #5 (MIDDLE, MIDDLE)
                    ZStack{
                        if TutorialComplete == true {
                        CheckFloorType()
                        } else if CurrentDungeon == 1 && TutorialComplete == false {
                            Image("Floor.Stone")
                            .resizable()
                                    .foregroundColor(Color.white)
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                    .cornerRadius(5)
                        }
                        if CharacterPlacement == 5 {
            ZStack{
                Button(action: {
                    
                    if CurrentHeroHealth != MaxHeroHealth {
                        CurrentHeroHealth = MaxHeroHealth
                    }
                    
                    CurrentScreen = 1
                    Trophy += trophyGain
                    if TutorialComplete == false {
                        TutorialComplete = true
                    }
                    
                    if Trophy <= 1000 {
                        CurrentDungeon = 1
                    } else if Trophy > 1000 && Trophy <= 2000 {
                        CurrentDungeon = 2
                    } else if Trophy > 2000 && Trophy <= 3000 {
                        CurrentDungeon = 3
                    } else if Trophy > 3000 && Trophy <= 4000 {
                        CurrentDungeon = 4
                    } else if Trophy > 4000 && Trophy <= 5000 {
                        CurrentDungeon = 5
                    } else if Trophy > 5000 && Trophy <= 6000 {
                        CurrentDungeon = 6
                    } else if Trophy > 6000 && Trophy <= 7000 {
                        CurrentDungeon = 7
                    } else if Trophy > 7000 && Trophy <= 8000 {
                        CurrentDungeon = 8
                    } else if Trophy > 8000 && Trophy <= 9000 {
                        CurrentDungeon = 9
                    } else if Trophy > 9000 && Trophy <= 10000 {
                        CurrentDungeon = 10
                    } else if Trophy >= 10000 {
                        //Final Dungeon, League Play (Comps?) Last EDIT: 3/14/21 (Happy Pi Day)
                        CurrentDungeon = 11
                    }

                    
                }) {
                    ZStack {
                Rectangle()
                    .frame(width: 2000, height: 2000)
                    .edgesIgnoringSafeArea(.all)
                    .foregroundColor(Color(red: 211/255, green: 232/255, blue: 140/255))
                
                        Rectangle()
                            .frame(width: 2000, height: 2000)
                            .edgesIgnoringSafeArea(.all)
                            .foregroundColor(Color(red: 120/255, green: 212/255, blue: 115/255))
                            .opacity(0.5)
                    }
                }
                        VStack{
                            Image("Trophy.Reward")
                                .scaleEffect(1.25)
                        Text("YOU WON")
                            .bold()
                            .foregroundColor(Color.white)
                            HStack{
                        Text("You Gained +" + String(trophyGain) + " Trophies")
                            .bold()
                            .foregroundColor(Color.white)
                            }
                            ZStack{
                        Text("(Press Anywhere To Continue)")
                            .bold()
                            .foregroundColor(Color.black)
                            .padding(.all, 10)
                            }
                            Image("Trophy.Reward")
                                .scaleEffect(1.25)
                        }
            }
                    
                        } else {
                            Image("Trophy.Reward")
                                .scaleEffect(1.25)
                        }
                        // CharacterDirection()
                        // EXTRA. IF TROPHY LOCATION MOVES AS OF JANUARY 14, 2021
                    }
            //TILE #6 (MIDDLE RIGHT SIDE)
                    ZStack{
                        CheckWallType()

                        if CharacterPlacement == 6{
                            Image("Hero.TDV")
                                .rotationEffect(.degrees(90))
                                .scaleEffect(1.5)
                            }
                        }
                    }
            HStack{
                //TILE #7 (BOTTOM LEFT SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 7{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                   
                            }
                        }
                //TILE #8 (MIDDLE BOTTOM SIDE)
                            ZStack{
                                CheckWallType()

                            if CharacterPlacement == 8{
                                Image("Hero.TDV")
                                    .scaleEffect(1.5)
                                    
                                }
                            }
                //TILE #9 (BOTTOM RIGHT CORNER)
                                ZStack{
                                    CheckWallType()
                                if CharacterPlacement == 9{
                                    Image("Hero.TDV")
                                        .scaleEffect(1.5)
                                        
                                }
                            }
                        }
            Spacer__()
    }
}

struct TileSetTwentySix_Previews: PreviewProvider {
    static var previews: some View {
        TileSetTwentySix()
    }
}
