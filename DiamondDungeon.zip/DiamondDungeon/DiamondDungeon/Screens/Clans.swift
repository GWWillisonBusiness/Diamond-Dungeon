//
//  Clans.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/27/20.
//

import SwiftUI

struct Clans: View {
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        NavigationView{
        ZStack{
            
            Rectangle()
                .foregroundColor(Color.blue)
                .edgesIgnoringSafeArea(.all)
                .opacity(0.69)
            Rectangle()
                .foregroundColor(Color.green)
                .edgesIgnoringSafeArea(.all)
                .opacity(0.33)
            
                
            
            VStack{
            ScrollViewReader { scrollView in
                ScrollView {
            
                Text("Clans")
                    .font(.system(size: 27))
                    .bold()
                    }
                }
            
                Spacer__()
        HStack{
            ZStack{
                LittleSquare()
                NavigationLink(destination: Shop()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Shop")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Inventory()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Inv")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Homescreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Play")
                    
                }

            }
            ZStack{
                LittleSquare()
                    Text("Clans")
                    
                
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Skills()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Skills")
                                }
                            }
                        }
                
                    }
            .gesture(DragGesture(minimumDistance: 5, coordinateSpace: .global)
                        .onEnded { value in
                            let horizontalAmount = value.translation.width as CGFloat
                            let verticalAmount = value.translation.height as CGFloat
                            
                            if abs(horizontalAmount) > abs(verticalAmount) {
                                if horizontalAmount < 0 {
                                    //RIGHT
                                    CurrentScreen = 5
                                } else if horizontalAmount > 0 {
                                    //LEFT
                                    CurrentScreen = 1
                                }
                            }
                        })
            }
        }
    }
}

struct Clans_Previews: PreviewProvider {
    static var previews: some View {
        Clans()
    }
}
