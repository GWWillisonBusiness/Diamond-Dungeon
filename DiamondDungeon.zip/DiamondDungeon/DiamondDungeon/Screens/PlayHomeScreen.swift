//
//  PlayHomeScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/27/20.
//

import SwiftUI

struct PlayHomeScreen: View {
    var body: some View {
        
        NavigationView{
            VStack{
                Text("Play")
                
        HStack{
            ZStack{
                LittleSquare()
                NavigationLink(destination: Shop()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Shop")
                    
                }
            }
            ZStack{
                LittleSquare()
                LittleSquare()
                NavigationLink(destination: Inventory()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Inv")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: PlayHomeScreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Play")
                    
                }

            }
            ZStack{
                LittleSquare()
                LittleSquare()
                NavigationLink(destination: Clans()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Clans")
                    
                }
            }
            ZStack{
                LittleSquare()
                LittleSquare()
                NavigationLink(destination: PlayHomeScreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Skills")
                }
                }
                    }
                }
        }
    }
}

struct PlayHomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        PlayHomeScreen()
    }
}
