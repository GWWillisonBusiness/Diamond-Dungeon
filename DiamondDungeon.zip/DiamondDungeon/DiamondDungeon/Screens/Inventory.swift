//
//  Inventory.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/27/20.
//

import SwiftUI

struct Inventory: View {
    @AppStorage ("DamageItemClicked") var DamageItemClicked = false
    @AppStorage ("HealthItemClicked") var HealthItemClicked = false
    
    @AppStorage ("WeaponInventory") var WeaponInventory = false
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    @State var TestInv = 0
    
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("WeaponScreenActive") var IronSwordWeaponScreenActive = false
    @AppStorage ("WeaponScreenActive") var FlameSpearWeaponScreenActive = false
    
    @AppStorage ("WeaponScreenActive") var WeaponScreenActive = false
  @AppStorage ("InvValue")  var InventoryValue = 0
    @AppStorage ("IronSwordPurchase") var IronSwordPurchase = false
    var body: some View {
        NavigationView{
        ZStack{
            Rectangle()
                .foregroundColor(Color.blue)
                .edgesIgnoringSafeArea(.all)
                .opacity(0.69)
            Rectangle()
                .foregroundColor(Color.green)
                .edgesIgnoringSafeArea(.all)
                .opacity(0.33)
           
            
            VStack{
                ScrollViewReader { scrollView in
                    ScrollView {
                Text("Inventory")
                    .font(.system(size: 27))
                    .bold()

                        HStack{
                            //Enemy Attack & Health
                            ZStack{
                                if HealthItemClicked == false {
                            Image("BackgroundBar")
                                    Image("Heart")
                                    Text(String(CurrentHeroHealth))
                                        .foregroundColor(Color.white)
                                } else if HealthItemClicked == true {
                                    Image("BackgroundBar")
                                            Image("Heart")
                                                .scaleEffect(2)
                                            Text(String(CurrentHeroHealth))
                                                .foregroundColor(Color.white)
                                }
                            }//ZStack
                            ZStack{
                                if DamageItemClicked == false {
                            Image("BackgroundBar")
                                Image("Sword.Free")
                                Text(String(CurrentHeroAttack))
                                    .foregroundColor(Color.white)
                                } else if DamageItemClicked == true {
                                    Image("BackgroundBar")
                                        Image("Sword.Free")
                                            .scaleEffect(1.7)
                                        Text(String(CurrentHeroAttack))
                                            .foregroundColor(Color.white)
                                }
                            }//ZStack
                        } //HStack
                
                Spacer()
                        ZStack {
                            if WeaponInventory == false {
                        InventoryCharacterInfo()
                            }
                            if  WeaponInventory == true {
                                VStack {
                                    
                                InventoryInfo()
                                    Button(action: {
                                        if WeaponInventory == true {
                                        WeaponInventory = false
                                        }
                                    }) {
                                        Image("BackArrow")
                                    }
                                }
                            }
                        }//ZStack
                Spacer()
                    }
                }
        HStack{
            ZStack{
                LittleSquare()
                NavigationLink(destination: Shop()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Shop")
                    
                }
            }
            ZStack{
                        LittleSquare()
                        Text("Inv")
                
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Homescreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Play")
                    
                }

            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Clans()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Clans")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Skills()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Skills")
                                }
                            }
                        
                    }
                }
            
            //Swipe To Other Screen (Gesture)
            .gesture(DragGesture(minimumDistance: 5, coordinateSpace: .global)
                        .onEnded { value in
                            let horizontalAmount = value.translation.width as CGFloat
                            let verticalAmount = value.translation.height as CGFloat
                            
                            if abs(horizontalAmount) > abs(verticalAmount) {
                                if horizontalAmount < 0 {
                                    //RIGHT
                                    CurrentScreen = 1
                                } else if horizontalAmount > 0 {
                                    //LEFT
                                    CurrentScreen = 2
                                }
                            }
                        })
            
            }
        }
    }
}

struct Inventory_Previews: PreviewProvider {
    static var previews: some View {
        Inventory()
    }
}
