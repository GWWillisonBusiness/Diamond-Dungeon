//
//  Skills.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/27/20.
//

import SwiftUI

struct Skills: View {
    //Currency
    @AppStorage ("SkillOrbs") var SkillOrbs = 0
    
    //All Skils and The Value of The Skill (T or F)
    @AppStorage("WaterWalking") var WaterWalking = false
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    
    var body: some View {
        
        NavigationView{
            
            ZStack{
                //Background Color and Shape
                Rectangle()
                    .foregroundColor(Color.blue)
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.69)
                Rectangle()
                    .foregroundColor(Color.green)
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.33)
                
                                    
                
                ScrollViewReader { scrollView in
                    ScrollView {
            VStack{
                Text("Skills")
                    .bold()
                
                ZStack {
                    Image("Bar.Username")
                        .scaleEffect(2.0)
                    HStack(spacing: 0){
                        Spacer3()
                        Spacer()
                        Text(String(SkillOrbs))
                            .foregroundColor(Color.white)
                            .font(.system(size: 31))
                            .bold()
                        Image("Skill.Orb")
                            .scaleEffect(0.36)
                        Spacer3()
                    }
                }
                ZStack {
                    HStack {
                    LittleSquare()
                        .opacity(0.0)
                        Button(action :{
                            if SkillOrbs > 0 && WaterWalking == false {
                                SkillOrbs -= 1
                                WaterWalking = true
                            }
                        }) {
                            if WaterWalking == false {
                    LittleSquare()
                            } else if WaterWalking == true {
                                Rectangle()
                                .foregroundColor(Color.green)
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .cornerRadius(20)
                                .opacity(0.94)
                            }
                        }
                    LittleSquare()
                        .opacity(0.0)
                    }
                    VStack(spacing: 0){
                    Text("Water")
                        .bold()
                        .foregroundColor(Color.blue)
                    Text("Walking")
                        .bold()
                        .foregroundColor(Color.blue)
                        }
                
                
            }
        }//VStack
                    }
            Spacer__()
                
                
        HStack{
            ZStack{
                LittleSquare()
                NavigationLink(destination: Shop()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Shop")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Inventory()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Inv")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Homescreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Play")
                    
                }

            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Clans()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Clans")
                    
                }
            }
            ZStack{
                LittleSquare()
                    Text("Skills")
                
                            }
                        }
                    }
                
                .gesture(DragGesture(minimumDistance: 5, coordinateSpace: .global)
                            .onEnded { value in
                                let horizontalAmount = value.translation.width as CGFloat
                                let verticalAmount = value.translation.height as CGFloat
                                
                                if abs(horizontalAmount) > abs(verticalAmount) {
                                    if horizontalAmount < 0 {
                                        //RIGHT
                                    } else if horizontalAmount > 0 {
                                        //LEFT
                                        CurrentScreen = 4
                                    }
                                }
                            })

                
                }
            }
    }
}

struct Skills_Previews: PreviewProvider {
    static var previews: some View {
        Skills()
    }
}
