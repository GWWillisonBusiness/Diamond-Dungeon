//
//  ContentView.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/26/20.
//

import SwiftUI

struct Homescreen: View {
    @AppStorage ("CheckTile") var CheckTile = 0
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("ChestValue") var ChestValue = 0
    
    @AppStorage ("Username") var Username:String = ""
    
    @AppStorage ("ChestOpen") var ChestOpen = false
    @AppStorage ("RubyKeyEquipped") var RubyKeyEquipped = false
    
    // In-Game Items
    @AppStorage ("BombEquipped") var BombEquipped = false
    @AppStorage ("BombUsed") var BombUsed = false
    
    @AppStorage ("WallCracked") var WallCracked = false
    
    @AppStorage ("MenuScreen") var MenuScreen = false
    
    //Current Active Tile Set That is Active
    @AppStorage ("NorthActiveTileSet") var NorthActiveTileSet = 0
    @AppStorage ("EastActiveTileSet") var EastActiveTileSet = 0
    @AppStorage ("SouthActiveTileSet") var SouthActiveTileSet = 0
    @AppStorage ("WestActiveTileSet") var WestActiveTileSet = 0
    
    // Some of The Tiles At Which You Will Move Into
    @AppStorage ("ZeroZero") var ZeroZero = 0
    @AppStorage ("ZeroNOne") var ZeroNOne = 0
    @AppStorage ("ZeroNTwo") var ZeroNTwo = 0
    @AppStorage ("ZeroNThree") var ZeroNThree = 0
    @AppStorage ("ZeroPOne") var ZeroPOne = 0
    @AppStorage ("ZeroPTwo") var ZeroPTwo = 0
    @AppStorage ("ZeroPThree") var ZeroPThree = 0
    @AppStorage ("POneZero") var POneZero = 0
    @AppStorage ("PTwoZero") var PTwoZero = 0
    @AppStorage ("PThreeZero") var PThreeZero = 0
    @AppStorage ("POneNOne") var POneNOne = 0
    @AppStorage ("POneNOne") var NOnePOne = 0
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false
    
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 10
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    @AppStorage ("EnemyDefeatedBoss") var EnemyDefeatedBoss = 0

    
    @AppStorage ("TileMapSelector") var TileMapSelector = 0
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var xBoardEdge = 0
    @AppStorage ("rightBoardEdge") var yBoardEdge = 0
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    @AppStorage("BackgroundColor") var backgroundColorValue = 1
    
    //Can I click the Button? (0 = No / 1 = Yes)
    @AppStorage ("HM") var homeScreenValue = 0
    
    //Map Active ( 0 = False) (1 = True)
    @AppStorage ("MapActive") var MapActive = 0
    
    //System of Currency
    @AppStorage ("Coin")    var Coins = 0
    @AppStorage ("Diamond")  var Diamond = 0
    @AppStorage ("Trophy")  var Trophy = 0
    
    @AppStorage ("trophyGain") var trophyGain = 10
    
    var body: some View {
        NavigationView{
            
        ZStack{
                
            
            if backgroundColorValue == 1 {

                let homeScreenValue = 1
                if homeScreenValue == 1 {
                }
                
                Rectangle()
                    .foregroundColor(Color.blue)
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.69)
                Rectangle()
                    .foregroundColor(Color.green)
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.33)
                
                VStack(spacing: 0){
      
            HStack{
                Spacer()
                ZStack{
                    Rectangle()
                        .aspectRatio(3, contentMode: .fit)
                        .foregroundColor(Color.gray)
                        .cornerRadius(10)
                        .border(Color.black, width: 4)
                    HStack(spacing: 0){
                        Text(String(Coins))
                            .bold()
                    Image("Coin")
                  
                    }
                }
                Spacer__()
                
                ZStack{
                    Rectangle()
                        .aspectRatio(3, contentMode: .fit)
                        .foregroundColor(Color.gray)
                        .cornerRadius(10)
                        .border(Color.black, width: 4)
                      
                    HStack(spacing: 0){
                        Text(String(Diamond))
                            .bold()
                    Image("Diamond")
                        
                    }
                }
            
                Spacer()
            }
            Spacer__()
                    HStack {
            ZStack{
                HStack {
                Rectangle()
                    .aspectRatio(3, contentMode: .fit)
                    .foregroundColor(Color.gray)
                    .border(Color.black, width: 4)                   
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(2.5, contentMode: .fit)
                    .foregroundColor(Color.gray)
                    .cornerRadius(10)
                    .border(Color.black, width: 4)
                Rectangle()
                    .aspectRatio(3, contentMode: .fit)
                    .foregroundColor(Color.gray)
                    .border(Color.black, width: 4)
                    .opacity(0.0)
                }
                HStack(spacing: 0){
                    Text(String(Trophy))
                        .bold()
                Image("Trophy.Reward")
                }
            }
                    }
        Spacer()
   
                    HStack {
                        Spacer()
                        Text("")
                        Spacer()
            ZStack {
                //Dungeon Image
                //Current Dungeon Picture
                if CurrentDungeon == 1 {
            Image("Dungeon.One.WBG")
                .resizable()
            .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                .shadow(radius: 10)
                } else if CurrentDungeon == 2 {
                    Image("Dungeon.Two.WBG")
                        .resizable()
                    .aspectRatio(contentMode: .fit)
                    .edgesIgnoringSafeArea(.all)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                } else if CurrentDungeon == 3 {
                    Image("Dungeon.Three.WBG")
                        .resizable()
                    .aspectRatio(contentMode: .fit)
                    .edgesIgnoringSafeArea(.all)
                        .cornerRadius(20)
                        .shadow(radius: 10)
                }

            } //ZStack
                        Spacer()
                        Text("")
                        Spacer()
                    }

            Spacer()
            ZStack{
                Text("Play")
                    .bold()
                    .foregroundColor(.white)
                    .padding(.all, 15)
                    .padding([.leading, .trailing], 30)
                    .background(Color.gray)
                    .cornerRadius(20)
                    .shadow(radius: 15)
                   Button("                           "){
                    let impactMed = UIImpactFeedbackGenerator(style: .medium)
                        impactMed.impactOccurred()
                    
                    //What Tiles Will Pop-up
                    CheckTile = Int.random(in: 1..<4)
                    
                    //Potential Trophies Earned
                    trophyGain = Int.random(in: 10..<16)
                    ChestValue = Int.random(in: 1..<10)
                    
                    //Reset In Game Items
                    BombEquipped = false
                    BombUsed = false
                    WallCracked = false
                    RubyKeyEquipped = false
                    ChestOpen = false
                    
                    //MAP
                    NorthActiveTileSet = 0
                    WestActiveTileSet = 0
                    EastActiveTileSet = 0
                    SouthActiveTileSet = 0
                    
                    //Choose Tile Sets To Setup For The Map of The Dungeon (Active of: 2/11/2021)
                    NorthActiveTileSet = Int.random(in: 1..<8)
                    EastActiveTileSet = Int.random(in: 1..<8)
                    WestActiveTileSet = Int.random(in: 1..<8)
                    SouthActiveTileSet = Int.random(in: 1..<9)
                    
                    //Checks To Make Sure A Trophy Spawns Into The Map
                    while NorthActiveTileSet != 1 && WestActiveTileSet != 2 && EastActiveTileSet != 3 && SouthActiveTileSet != 4 && NorthActiveTileSet != 5 && WestActiveTileSet != 6 && EastActiveTileSet != 7 && SouthActiveTileSet != 8 {
                        
                        NorthActiveTileSet = Int.random(in: 1..<8)
                        EastActiveTileSet = Int.random(in: 1..<8)
                        WestActiveTileSet = Int.random(in: 1..<8)
                        SouthActiveTileSet = Int.random(in: 1..<9)
                    }
                    
                    //Checks To Make Sure Only One Exit Spawns Into The Tile Map
                    if NorthActiveTileSet == 1 {
                        while WestActiveTileSet == 2 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 3 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while SouthActiveTileSet == 4 {
                            SouthActiveTileSet = Int.random(in: 1..<9)
                        }
                        while NorthActiveTileSet == 5 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 6 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 7 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                    }  else if WestActiveTileSet == 2 {
                        while EastActiveTileSet == 7 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 3 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while NorthActiveTileSet == 1 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while SouthActiveTileSet == 4 {
                            SouthActiveTileSet = Int.random(in: 1..<9)
                        }
                        while NorthActiveTileSet == 5 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 6 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                    }  else if EastActiveTileSet == 3 {
                        while EastActiveTileSet == 7 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 2 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while NorthActiveTileSet == 1 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while SouthActiveTileSet == 4 {
                            SouthActiveTileSet = Int.random(in: 1..<9)
                        }
                        while NorthActiveTileSet == 5 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 6 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                    } else if SouthActiveTileSet == 4 {
                        while EastActiveTileSet == 7 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 6 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 2 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while NorthActiveTileSet == 1 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 3 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while NorthActiveTileSet == 5 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                    } else if NorthActiveTileSet == 5 {
                        while EastActiveTileSet == 7 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 6 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 2 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 3 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while SouthActiveTileSet == 4 {
                            SouthActiveTileSet = Int.random(in: 1..<9)
                        }
                        while NorthActiveTileSet == 1 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                    } else if WestActiveTileSet == 6 {
                        while EastActiveTileSet == 7 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 2 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 3 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while SouthActiveTileSet == 4 {
                            SouthActiveTileSet = Int.random(in: 1..<9)
                        }
                        while NorthActiveTileSet == 1 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while NorthActiveTileSet == 5 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                     }  else if EastActiveTileSet == 7 {
                        while WestActiveTileSet == 6 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while WestActiveTileSet == 2 {
                            WestActiveTileSet = Int.random(in: 1..<8)
                        }
                        while EastActiveTileSet == 3 {
                            EastActiveTileSet = Int.random(in: 1..<8)
                        }
                        while SouthActiveTileSet == 4 {
                            SouthActiveTileSet = Int.random(in: 1..<9)
                        }
                        while NorthActiveTileSet == 1 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                        while NorthActiveTileSet == 5 {
                            NorthActiveTileSet = Int.random(in: 1..<8)
                        }
                    } else if SouthActiveTileSet == 8 {
                        //BOSS BATTLE
                        NorthActiveTileSet = 0
                        EastActiveTileSet = 0
                        WestActiveTileSet = 0
                    }
                    

                    //Player Direction
                    FacingUp = true
     
                    //Making Sure Player Spawns In.
                    if FacingUp == false && FacingDown == false && FacingLeft == false && FacingRight == false {
                        FacingUp = true
                    }
                    
                    if TileMapSelector < 3 {
                        TileMapSelector += 1
                    } else if TileMapSelector == 3 || TileMapSelector > 3 {
                        TileMapSelector -= 2
                    }
                       CurrentScreen = 6
                    
                        EnemyDefeated1 = 0
                        EnemyDefeated2 = 0
                        EnemyDefeated3 = 0
                        EnemyDefeated4 = 0
                        EnemyDefeated5 = 0
                        EnemyDefeated6 = 0
                        EnemyDefeatedBoss = 0
                    
                       xBoardEdge = 0
                       yBoardEdge = 0
                    
                    if CurrentHeroHealth != MaxHeroHealth {
                        CurrentHeroHealth = MaxHeroHealth
                    }
                    
                   }
                }
            
            Spacer__()
            HStack{
                ZStack{
                    LittleSquare()
                    NavigationLink(destination: Shop()
                                    .navigationTitle(Text(""))
                                    .navigationBarHidden(true)){
                        Text("Shop")
                        
                    }
                }
                ZStack{
                    LittleSquare()
                    NavigationLink(destination: Inventory()
                                    .navigationTitle(Text(""))
                                    .navigationBarHidden(true)){
                        Text("Inv")
                        
                    }
                }
                ZStack{
                    LittleSquare()
                    Text("Play")
                }
                ZStack{
                    LittleSquare()
                    NavigationLink(destination: Clans()
                                    .navigationTitle(Text(""))
                                    .navigationBarHidden(true)){
                        Text("Clans")
                        
                    }
                }
                ZStack{
                    LittleSquare()
                    NavigationLink(destination: Skills()
                                    .navigationTitle(Text(""))
                                    .navigationBarHidden(true)){
                            Text("Skills")
                                    }
                                }
                            }
                        }
                .gesture(DragGesture(minimumDistance: 5, coordinateSpace: .global)
                            .onEnded { value in
                                let horizontalAmount = value.translation.width as CGFloat
                                let verticalAmount = value.translation.height as CGFloat
                                
                                if abs(horizontalAmount) > abs(verticalAmount) {
                                    if horizontalAmount < 0 {
                                        //RIGHT
                                        CurrentScreen = 4
                                    } else if horizontalAmount > 0 {
                                        //LEFT
                                        CurrentScreen = 3
                                    }
                                }
                            })

                }
            }
        }
    }
}

struct Homescreen_Previews: PreviewProvider {
    static var previews: some View {
        Homescreen()
    }
}
