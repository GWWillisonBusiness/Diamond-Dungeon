//
//  Shop.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/26/20.
//

import SwiftUI

struct Shop: View {
    // The Value of The Crate Helps Determine: Animation, and Location
    @AppStorage ("WoodenCrateValue") var WoodenCrateValue = 0
    @AppStorage ("CrateScreen") var CrateScreen = false
    
    @AppStorage ("ShopBackground") var ShopBackground = 1
    @AppStorage ("Shop") var shopValue = 0
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
  
    var body: some View {
        
        NavigationView{
    ZStack{
        Rectangle()
            .foregroundColor(Color.blue)
            .edgesIgnoringSafeArea(.all)
            .opacity(0.69)
        Rectangle()
            .foregroundColor(Color.green)
            .edgesIgnoringSafeArea(.all)
            .opacity(0.33)
        
       
 
        VStack{
      
            
        ScrollViewReader { scrollView in
            ScrollView {
                
              
                if ShopBackground == 1 {
                 
                Text("Shop")
                    .font(.system(size: 40))
                    .bold()
                    .foregroundColor(Color.white)
                    .edgesIgnoringSafeArea(.top)
                    
                }
        //Actual Shop Info
                Spacer()
                ZStack {
                    if CrateScreen == false {
             ShopInfo()
                }
                if CrateScreen == true {
                    DiamondDungeon.CrateScreen()
                    }
                }
                Spacer()
            
        
            
            }
        }
                Spacer__()
        HStack{
            ZStack{
                LittleSquare()
                Text("Shop")
            }
        ZStack{
                LittleSquare()
                NavigationLink(destination: Inventory()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true))
                {
                    Text("Inv")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Homescreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Play")
                    
                }

            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Clans()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Clans")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Skills()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Skills")
                                
                            }
                        }
                    }
                }
        
        .gesture(DragGesture(minimumDistance: 5, coordinateSpace: .global)
                    .onEnded { value in
                        let horizontalAmount = value.translation.width as CGFloat
                        let verticalAmount = value.translation.height as CGFloat
                        
                        if abs(horizontalAmount) > abs(verticalAmount) {
                            if horizontalAmount < 0 {
                                //RIGHT
                                CurrentScreen = 3
                            } else if horizontalAmount > 0 {
                                //LEFT
                        
                            }
                        }
                    })
        
            }
        }
    }
}
struct Shop_Previews: PreviewProvider {
    static var previews: some View {
        Shop()
    }
}
