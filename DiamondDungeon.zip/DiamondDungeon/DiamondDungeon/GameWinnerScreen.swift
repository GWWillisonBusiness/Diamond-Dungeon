//
//  GameWinnerScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/1/20.
//

import SwiftUI

struct GameWinnerScreen: View {
    var body: some View {
        LittleSquare()
        
    }
}

struct GameWinnerScreen_Previews: PreviewProvider {
    static var previews: some View {
        GameWinnerScreen()
    }
}
