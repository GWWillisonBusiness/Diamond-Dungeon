//
//  TreasureChest.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 2/27/21.
//

import SwiftUI

struct TreasureChest: View {
    //PROBLEM, WHEN RESTARTING APP, VALUES CHANGE
    @AppStorage ("ChestValue") var ChestValue = 0
    @State var CoinIncrease = Int.random(in: 10..<36)
    
    @AppStorage ("InsideChest") var InsideChest = 0
    @AppStorage ("RubyKeyEquipped") var RubyKeyEquipped = false
    
    @AppStorage ("ChestOpen") var ChestOpen = false
    
    @AppStorage ("Coin")  var Coins = 0
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(Color.red)
                .edgesIgnoringSafeArea(.all)
                .opacity(0.58)
            Rectangle()
                .foregroundColor(Color.orange)
                .edgesIgnoringSafeArea(.all)
                .opacity(0.42)
            VStack {
                if ChestValue == 1 {
                Text("YOU FOUND THE RUBY KEY")
                    .bold()
                    .foregroundColor(Color.black)
                } else {
                    Text("You Found " + String(CoinIncrease) + " Coins")
                        .bold()
                        .foregroundColor(Color.black)
                }
        Button(action: {
            if ChestValue == 1 {
            RubyKeyEquipped = true
            ChestOpen = true
            CurrentScreen = 6
            } else if ChestValue == 2  || ChestValue == 3 || ChestValue == 4 || ChestValue == 5 || ChestValue == 6 || ChestValue == 7 || ChestValue == 8 || ChestValue == 9 {
                Coins += CoinIncrease
                ChestOpen = true
                CurrentScreen = 6
            }
        }) {

            ZStack{
                LittleSquare()
                if ChestValue == 1 {
                Image("Item.RubyKey")
                    .rotationEffect(Angle(degrees: 22))
                    .aspectRatio(contentMode: .fit)
                } else {
                    
                    Image("Coin")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
        
                    
                    
                }
                    }
            }
            Text("(Press To Continue)")
                .bold()
                .foregroundColor(Color.black)
                
            }
        }
    }
}

struct TreasureChest_Previews: PreviewProvider {
    static var previews: some View {
        TreasureChest()
    }
}
