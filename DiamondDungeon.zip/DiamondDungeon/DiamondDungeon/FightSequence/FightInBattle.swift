//
//  FightInBattle.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/3/20.
//

import SwiftUI

struct FightInBattle: View {
    @AppStorage ("EnemyHit") var EnemyHit = false
    @AppStorage ("HeroHit") var HeroHit = false
    
    @AppStorage ("CheckAttackHero") var CheckAttackHero = false
    @AppStorage ("CheckAttackEnemy") var CheckAttackEnemy = false
    @AppStorage ("AnimateChangeAttack") var AnimateChangeAttack = 0
    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeatedBoss") var EnemyDefeatedBoss = 0
    
    @AppStorage ("EnemyValue") var EnemyValue = Int.random(in: 1..<4)
    @AppStorage ("EnemyHasBeenChosen") var EnemyHasBeenChosen = false
    @AppStorage ("EnemyLevel") var EnemyLevel = 1
    
    //   0 = False    1 = True
    @AppStorage ("EFOS") var EnemyFlashOnScreen = 0
    @AppStorage ("HFOS") var HeroFlashOnScreen = 0
    
    @AppStorage ("ItemScreenActive") var ItemScreenActive = 0
    
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 20
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("CurrentEnemyHealth") var CurrentEnemyHealth = 4
    @AppStorage ("CurrentEnemyAttack") var CurrentEnemyAttack = 1

    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        if CurrentScreen == 9 {
            
        //  BACKGROUND
        ZStack{
            VStack {
                
                ZStack {
            Rectangle()
                .foregroundColor(Color.red)
                .edgesIgnoringSafeArea(.all)
                .aspectRatio(contentMode: .fill)
                    VStack{
                        Spacer3()
                        Spacer3()
                            HStack{
                                //Enemy Attack & Health
                                ZStack{
                                Image("BackgroundBar")
                                        Image("Heart")
                                        Text(String(CurrentEnemyHealth))
                                            .foregroundColor(Color.white)
                                }//ZStack
                                ZStack{
                                Image("BackgroundBar")
                                    Image("Sword.Free")
                                    Text(String(CurrentEnemyAttack))
                                        .foregroundColor(Color.white)
                                        
                                }//ZStack
                            } //HStack
                        ZStack {
                        if EnemyDefeatedBoss == 1 {
                            if CheckAttackEnemy == false {
                                if EnemyHit == false {
                            Image("Enemy.Boss")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .shadow(radius: 8)
                                .offset(y: -40)
                                .animation(.easeIn)
                                } else if EnemyHit == true {
                                    ZStack {
                                        Image("Enemy.Boss")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .shadow(radius: 8)
                                            .offset(y: -40)
                                            .animation(.easeIn)
                                        Image("Character.Hit")
                                            .scaleEffect(6)
                                    }
                                }
                            } else if CheckAttackEnemy == true {
                                Image("Enemy.Boss")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .shadow(radius: 8)
                                    .offset(y: 10)
                                    .animation(.easeIn)
                                
                            }
                        } else if EnemyLevel == 1 {
                            if CheckAttackEnemy == false {
                                if EnemyHit == false {
                            Image("Enemy.NightBat")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .shadow(radius: 8)
                                .offset(y: -40)
                                .animation(.easeIn)
                                } else if EnemyHit == true {
                                    ZStack {
                                    Image("Enemy.NightBat")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .shadow(radius: 8)
                                        .offset(y: -40)
                                        .animation(.easeIn)
                                    Image("Character.Hit")
                                        .scaleEffect(6)
                                    }
                                }
                            } else if CheckAttackEnemy == true {
                                Image("Enemy.NightBat")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .shadow(radius: 8)
                                    .offset(y: 10)
                                    .animation(.easeIn)
                            }
                    } else if EnemyLevel == 2 {
                        if CheckAttackEnemy == false {
                            if EnemyHit == false {
                        Image("Enemy.GreenGhost")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .shadow(radius: 8)
                            .offset(y: -40)
                            .animation(.easeIn)
                            } else if EnemyHit == true {
                                ZStack {
                                Image("Enemy.GreenGhost")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .shadow(radius: 8)
                                    .offset(y: -40)
                                    .animation(.easeIn)
                                Image("Character.Hit")
                                    .scaleEffect(6)
                                }
                            }
                        } else if CheckAttackEnemy == true {
                            Image("Enemy.GreenGhost")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .shadow(radius: 8)
                                .offset(y: 10)
                                .animation(.easeIn)
                        }
                    } else if EnemyLevel == 3 {
                        if CheckAttackEnemy == false {
                            if EnemyHit == false {
                        Image("Enemy.SmallRedBlob")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .shadow(radius: 8)
                            .offset(y: -40)
                            .animation(.easeIn)
                            } else if EnemyHit == true {
                                ZStack {
                                    Image("Enemy.SmallRedBlob")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .shadow(radius: 8)
                                        .offset(y: -40)
                                        .animation(.easeIn)
                                    Image("Character.Hit")
                                        .scaleEffect(6)
                                }
                            }
                        } else if CheckAttackEnemy == true {
                            Image("Enemy.SmallRedBlob")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .shadow(radius: 8)
                                .offset(y: 10)
                                .animation(.easeIn)
                        }
                    }
                        }//ZStack
                    }//VStack
                }//ZStack
                ZStack {
                Rectangle()
                    .foregroundColor(Color.white)
                    .edgesIgnoringSafeArea(.all)
                    .aspectRatio(contentMode: .fill)
                    
                    VStack{
                        
                        if CheckAttackHero == false {
                            if HeroHit == false {
                        Image("Hero.Basic")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .shadow(radius: 14)
                            .offset(y: 0)
                            .animation(.easeIn)
                            } else if HeroHit == true {
                                ZStack {
                                Image("Hero.Basic")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .shadow(radius: 14)
                                    .offset(y: 0)
                                    .animation(.easeIn)
                                Image("Character.Hit")
                                    .scaleEffect(6)
                                }
                            }
                        } else if CheckAttackHero == true {
                            Image("Hero.Basic")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .shadow(radius: 14)
                                .offset(y: -33)
                                .animation(.easeIn)
                        }
                        
                            HStack{
                                //Enemy Attack & Health
                                ZStack{
                                Image("BackgroundBar")
                                        Image("Heart")
                                        Text(String(CurrentHeroHealth))
                                            .foregroundColor(Color.white)
                                }//ZStack
                                ZStack{
                                Image("BackgroundBar")
                                    Image("Sword.Free")
                                    Text(String(CurrentHeroAttack))
                                        .foregroundColor(Color.white)
                                        
                                }//ZStack
                            } //HStack
                        Spacer3()
                        Spacer3()
                    }//VStack
                }//ZStack
            } //VStack
            
            //Attack Button & Items Menu
            ZStack{
             Attack_Items()
            }
            
            
            }//ZStack
        }//Current Screen
    } // Code Portion (Body)
} // Struct
struct FightInBattle_Previews: PreviewProvider {
    static var previews: some View {
        FightInBattle()
    }
}
