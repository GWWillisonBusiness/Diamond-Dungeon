//
//  ItemsMenu.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/17/21.
//

import SwiftUI

struct ItemsMenu: View {
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        if CurrentScreen == 14 {
            ZStack {
            VStack{
                Spacer3()
            Text("This Is The Items Menu (UNDER DEVELOPMENT)")
                .bold()
                Circle()
                .foregroundColor(.black)
                .opacity(0.0)
                Circle()
                .foregroundColor(.black)
                .opacity(0.0)
                Circle()
                .foregroundColor(.black)
                .opacity(0.0)
                
                Circle()
                .foregroundColor(.black)
                .opacity(0.0)
           
                Circle()
                .foregroundColor(.black)
                .opacity(0.0)
                Circle()
                .foregroundColor(.black)
                .opacity(0.0)
                Button(action: {
                       CurrentScreen = 9
                }) {
                  

                    ZStack {
                    Circle()
                        .foregroundColor(.black)
                        Text("Back")
                        .foregroundColor(Color.red)
                        .bold()
                        }
                    }
            } //VStack
                
                Rectangle()
                    .foregroundColor(Color.gray)
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.2)
                
            }// ZStack
        }
    }
}

struct ItemsMenu_Previews: PreviewProvider {
    static var previews: some View {
        ItemsMenu()
    }
}
