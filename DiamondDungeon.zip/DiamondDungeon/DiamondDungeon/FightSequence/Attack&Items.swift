//
//  Attack&Items.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/17/21.
//

import SwiftUI

struct Attack_Items: View {
    @AppStorage ("AttackButtonPushed") var AttackButtonPushed = false
    @AppStorage ("EnemyHit") var EnemyHit = false
    @AppStorage ("HeroHit") var HeroHit = false
    
    // 1 = Homescreen, 2 = Shop, 3 = Inventory, 4 = Clans, 5 = Skills, 6 = Dungeon, 7 = Win Screen, 8 = Lost Screen, 9 = Battle Screen, 12 = Enemy Defeated, 13 = Hero Defeated
    @AppStorage ("CurrentScreen") var CurrentScreen = 1

    @AppStorage ("AnimateChangeAttack") var AnimateChangeAttack = 0
    
    @AppStorage ("CheckAttackHero") var CheckAttackHero = false
    @AppStorage ("CheckAttackEnemy") var CheckAttackEnemy = false
 
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("CurrentEnemyHealth") var CurrentEnemyHealth = 4
    @AppStorage ("CurrentEnemyAttack") var CurrentEnemyAttack = 1
    
    var body: some View {

        HStack{
            
            ZStack {
                Button(action: {
                    CurrentScreen = 14
                }) {
                    ZStack {
                    Circle()
                        .foregroundColor(Color.gray)
                        Text("Items")
                            .bold()
                            .foregroundColor(Color.white)
                    }
                }

            }//ZStack
            
            
            //Spacer, Using This Since Spacer() Does not Work.
            Circle()
                .opacity(0.0)
            
            Circle()
                .opacity(0.0)
            
            ZStack{
                if AttackButtonPushed == false {
                Button(action: {
                    let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
                        impactHeavy.impactOccurred()
                    
                    AttackButtonPushed = true
                    
                    if CheckAttackHero == false {
                        CheckAttackHero = true
                      
                    }
                    EnemyHit = true
                    //Sets Time Delay on Code Based on this number Here V
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                        CheckAttackHero = false
                        if CurrentHeroHealth > 0 {
                            CurrentEnemyHealth -= CurrentHeroAttack
                        }
                        EnemyHit = false
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
                  
                        if CurrentEnemyHealth < 1 {
                            CurrentScreen = 12
                        
                    }
                }
                    
                    //------------------HERO----------------------
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            
                    }
                    //------------------ENEMY---------------------
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    if CheckAttackEnemy == false {
                    CheckAttackEnemy = true
                        HeroHit = true
                        if CurrentEnemyHealth >= 1 {
                            CurrentHeroHealth -= CurrentEnemyAttack
                        }
                    }
                      //Sets Time Delay on Code Based on this number Here V
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                            CheckAttackEnemy = false
                            HeroHit = false
                            if CurrentHeroHealth <= 0 {
                                CurrentScreen = 13
                            }
                            AttackButtonPushed = false
                        }
                    }
                  
                    
                })
                {
                    ZStack {
                    Circle()
                        .foregroundColor(Color.gray)
                    Text("Attack")
                        .bold()
                        .foregroundColor(Color.white)
                        }
                    }
                } else {
                    ZStack {
                    Circle()
                        .foregroundColor(Color.gray)
                        
                    Text("Attack")
                        .bold()
                        .foregroundColor(Color.white)
                        .opacity(0.0)
                        }
                }
            }//ZStack
        }
        
    }
}

struct Attack_Items_Previews: PreviewProvider {
    static var previews: some View {
        Attack_Items()
    }
}
