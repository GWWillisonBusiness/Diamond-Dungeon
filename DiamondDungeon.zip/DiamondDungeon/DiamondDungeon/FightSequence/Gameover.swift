//
//  Gameover.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/9/20.
//

import SwiftUI

struct Gameover: View {
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 10
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("EnemyHasBeenChosen") var EnemyHasBeenChosen = false
    
    //System of Currency
    @AppStorage ("Coin")    var Coins = 0
    @AppStorage ("Diamond")  var Diamond = 0
    @AppStorage ("Trophy")  var Trophy = 0
    
    @AppStorage ("TrophyLoss") var TrophyLoss = 6
    
    // 1 = Homescreen, 2 = Shop, 3 = Inventory, 4 = Clans, 5 = Skills, 6 = Dungeon, 7 = Win Screen, 8 = Lost Screen, 9 = Battle Screen, 12 = Enemy Defeated, 13 = Hero Defeated
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color.red)
                .opacity(0.9)
                .edgesIgnoringSafeArea(.all)
            
            Rectangle()
                .foregroundColor(Color.red)
                .rotationEffect(Angle(degrees: 45))
                .scaleEffect(0.8)
                .opacity(2.0)
            
            Rectangle()
                .foregroundColor(Color.red)
                .rotationEffect(Angle(degrees: 315))
                .scaleEffect(0.8)
                .opacity(2.0)
            
            VStack{
                Spacer3()
            Text("GAME OVER")
                .bold()
                .font(.system(size: 50))
                .foregroundColor(Color.black)
                Spacer3()
                Text("Loss")
                    .bold()
                    .underline()
                    .font(.system(size: 20))
       
                Text("-" + String(TrophyLoss) + " Trophy Loss")
                    .bold()
           Spacer__()
            ZStack{
                Text("Continue")
                    .bold()
                    .foregroundColor(Color.black)
                    .padding(.all, 18)
                    .padding([.leading, .trailing], 30)
                    .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                    .cornerRadius(20)
                Button("                                       "){
                    
                    TrophyLoss = Int.random(in: 5..<12)
                    
                    //Reset The Players HP
                    if MaxHeroHealth != CurrentHeroHealth {
                        CurrentHeroHealth = MaxHeroHealth
                    }
                    
                    if EnemyHasBeenChosen == true {
                        EnemyHasBeenChosen = false
                    }
                    
                    CurrentScreen = 1
                    if TrophyLoss > Trophy {
                        Trophy = 0
                    } else {
                    Trophy -= TrophyLoss
                        }
                    if Trophy <= 1000 {
                        CurrentDungeon = 1
                    } else if Trophy > 1000 && Trophy <= 2000 {
                        CurrentDungeon = 2
                    } else if Trophy > 2000 && Trophy <= 3000 {
                        CurrentDungeon = 3
                    } else if Trophy > 3000 && Trophy <= 4000 {
                        CurrentDungeon = 4
                    } else if Trophy > 4000 && Trophy <= 5000 {
                        CurrentDungeon = 5
                    } else if Trophy > 5000 && Trophy <= 6000 {
                        CurrentDungeon = 6
                    } else if Trophy > 6000 && Trophy <= 7000 {
                        CurrentDungeon = 7
                    } else if Trophy > 7000 && Trophy <= 8000 {
                        CurrentDungeon = 8
                    } else if Trophy > 8000 && Trophy <= 9000 {
                        CurrentDungeon = 9
                    } else if Trophy > 9000 && Trophy <= 10000 {
                        CurrentDungeon = 10
                    } else if Trophy >= 10000 {
                        //Final Dungeon, League Play (Comps?) Last EDIT: 3/14/21 (Happy Pi Day)
                        CurrentDungeon = 11
                    }
                      
                    }
                }
            Spacer3()
            }
        }
    }
}

struct Gameover_Previews: PreviewProvider {
    static var previews: some View {
        Gameover()
    }
}
