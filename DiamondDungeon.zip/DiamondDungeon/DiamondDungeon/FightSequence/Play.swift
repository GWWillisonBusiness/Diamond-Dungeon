//
//  Play.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/28/20.
//
// Theme Colors: Blue & White

import SwiftUI

struct Play: View {
    //System of Currency
    @AppStorage ("Coin")    var Coins = 0
    @AppStorage ("Diamond")  var Diamond = 0
    @AppStorage ("Trophy")  var Trophy = 0

    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage("WaterWalking") var WaterWalking = false
    
    //Tutorial Information
    @AppStorage ("TutPart2") var TutPart2 = false
    @AppStorage ("TutPart1") var TutPart1 = false
    @AppStorage ("TutorialComplete") var TutorialComplete = false

    //Check For Item Value
    @AppStorage ("BombEquipped") var BombEquipped = false
    @AppStorage ("BombUsed") var BombUsed = false
    @AppStorage ("RubyKeyEquipped") var RubyKeyEquipped = false
    @AppStorage ("ChestOpen") var ChestOpen = false
    
    @AppStorage ("WallCracked") var WallCracked = false
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1

    @AppStorage ("BrokenWall") var BrokenWall = false
    
    //Direction of Movement (RNG)
    @AppStorage ("DownRNG") var DownRNG = 0
    @AppStorage ("LeftRNG") var LeftRNG = 0
    @AppStorage ("RightRNG") var RightRNG = 0
    @AppStorage ("UpRNG") var UpRNG = 0
    
    //Current Active Tile Set That is Active
    @AppStorage ("NorthActiveTileSet") var NorthActiveTileSet = 1
    @AppStorage ("EastActiveTileSet") var EastActiveTileSet = 1
    @AppStorage ("SouthActiveTileSet") var SouthActiveTileSet = 1
    @AppStorage ("WestActiveTileSet") var WestActiveTileSet = 1
    
    
    @AppStorage ("EnemyHasBeenChosen") var EnemyHasBeenChosen = false
    @AppStorage ("EnemyLevel") var EnemyLevel = 1
    @AppStorage ("EnemyValue") var EnemyValue = Int.random(in: 1..<4)
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = true
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false
    
    @AppStorage ("LookSideways") var LookSideways = false
    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeatedBoss") var EnemyDefeatedBoss = 0
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    
    @AppStorage ("TileMapSelector") var TileMapSelector = 0
    @AppStorage ("GameWinnerScreen") var GameWinnerScreen = false
    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("ts6") var ts6 = 0

    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var xBoardEdge = 0
    @AppStorage ("rightBoardEdge") var yBoardEdge = 0

        var body: some View {
    ZStack{
        Rectangle()
            .foregroundColor(Color.gray)
            .edgesIgnoringSafeArea(.all)
            
        VStack{
            
            //----------------------LOG----------------------
            HStack {
            Text("N: " + String(NorthActiveTileSet))
            Text("W: " + String(WestActiveTileSet))
            Text("E: " + String(EastActiveTileSet))
            Text("S: " + String(SouthActiveTileSet))

            Text("X: " + String(xBoardEdge))
            Text("Y: " + String(yBoardEdge))
            }
            //----------------------LOG----------------------
            
            Spacer3()
            HStack {
                Rectangle()
                .foregroundColor(Color.white)
                    .aspectRatio(contentMode: .fit)
                .cornerRadius(20)
                    .opacity(0.0)
                ZStack {
            Rectangle()
            .foregroundColor(Color.white)
                .aspectRatio(contentMode: .fit)
            .cornerRadius(20)
                    if BombEquipped == false {
                Image("Game.Bomb")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .scaleEffect(0.7)
                    .opacity(0.0)
                    } else if BombEquipped == true {
                        Image("Game.Bomb")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .scaleEffect(0.7)
                    }
                    if BombUsed == true {
                        Image("Item.Used")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        
                    }
                }
                ZStack {
            Rectangle()
            .foregroundColor(Color.white)
                .aspectRatio(contentMode: .fit)
            .cornerRadius(20)
                    if RubyKeyEquipped == true {
                        Image("Item.RubyKey")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .rotationEffect(Angle(degrees: 22))
                    } else if RubyKeyEquipped == false {
                        Image("Item.RubyKey")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .rotationEffect(Angle(degrees: 22))
                            .opacity(0.0)
                    }
                }
            Rectangle()
            .foregroundColor(Color.white)
                .aspectRatio(contentMode: .fit)
            .cornerRadius(20)
                Rectangle()
                .foregroundColor(Color.white)
                    .aspectRatio(contentMode: .fit)
                .cornerRadius(20)
                    .opacity(0.0)
            }
            Spacer__()
           
            //Where To move the character when he goes off screen.
                TileBoardLocation()
            
// ------------------------------------------Tiles(UP)---Controls(Down)-----------------------
            HStack{
                VStack{
                        Button(action: {
                            //Button Action
                            CurrentScreen = 15
                        }) {
                            ZStack{
                            Circle()
                                .foregroundColor(Color.white)
                                .aspectRatio(contentMode: .fit)
                                .opacity(1.0)
                            Image("Inventory.Bag")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .scaleEffect(0.8)

                            }
                        }
                    //Left
                    ZStack{
                        Button(action: {
                            let impactLight = UIImpactFeedbackGenerator(style: .light)
                                impactLight.impactOccurred()
                            
                            if xBoardEdge == 0 && yBoardEdge == 0 {
                                TutPart1 = true
                                }
                            if xBoardEdge == 1 && yBoardEdge == 0 {
                                TutPart2 = true
                                }

                            
                            if EnemyHasBeenChosen == false {
                                EnemyHasBeenChosen = true
                                EnemyLevel = EnemyValue
                            }
                            
                            if CharacterPlacement == 5{
                        // Collision (Start)
                                if TutorialComplete == false {
                                    if xBoardEdge == 0 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if TutorialComplete == true {
                                
                                //Spawn (X = 0 and Y = 0)
                                if xBoardEdge == 0 && yBoardEdge == 0 {
                                    if SouthActiveTileSet != 8 {
                                    CharacterPlacement = 4
                                    } else {
                                       CharacterPlacement = 5
                                    }
                                }
                                //UP (From Y = 1 and Greater)
                                if NorthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == 1 {
                                   CharacterPlacement = 4
                                } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 2 && yBoardEdge == 1 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == -2 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                }  else if xBoardEdge == -2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                }
                                } else if NorthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 4
                                    }
                                } else if NorthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                        
                                    }
                                } else if NorthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 0 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 3 {
                                        CharacterPlacement = 4
                                    }  else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 4
                                    }
                                } else if NorthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                        
                                    }
                                }
                                
                                //Right (X = 1 and Greater)
                                if EastActiveTileSet == 1 {
                                if xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                    CharacterPlacement = 4
                                    }
                                } else if EastActiveTileSet == 2 {
                                  if  xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    }
                                } else if EastActiveTileSet == 3 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 5 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 4 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 5 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    }
                                } else if EastActiveTileSet == 4 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    }
                                } else if EastActiveTileSet == 5 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    }
                                } else if EastActiveTileSet == 6 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 7 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 4 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == 4 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 3 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 3 && yBoardEdge == 5 {
                                        CharacterPlacement = 5
                                    }
                                }
                                //Left (X = -1 and Lower)
                                if WestActiveTileSet == 1 {
                                if xBoardEdge == -1 && yBoardEdge == 0 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 2 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -3 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == 1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 3 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 4 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 5 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 6 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 7 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                        if CharacterPlacement == 5 {
                                            BombEquipped = true
                                        }
                                    }
                                }
                                //Down ( Y = -1 and Lower)
                                if SouthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == -1 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == 3 && yBoardEdge == -1 {
                                    CharacterPlacement = 4
                                } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                    CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == -2 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 2 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 4
                                    }
                                } else if SouthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -3 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -1 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -3 {
                                        CharacterPlacement = 4
                                    }
                                } else if SouthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 4
                                    } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 4
                                    }
                                } else if SouthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 8 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                }
                            }
                                
                            } else if CharacterPlacement == 6 {
                                
                                if CurrentDungeon == 2 {
                                    if (WaterWalking == false) && ((xBoardEdge == 1 && yBoardEdge == 1 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 5) || (xBoardEdge == 3 && yBoardEdge == 0 && EastActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == 0 && EastActiveTileSet == 5) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 6) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == 3 && EastActiveTileSet == 7) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 1) || (xBoardEdge == 3 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 2 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == -2 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 5) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 3) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 5) || (xBoardEdge == 0 && yBoardEdge == -1 && SouthActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == -1 && EastActiveTileSet == 3) || (xBoardEdge == 2 && yBoardEdge == 0 && NorthActiveTileSet == 2)) {
                                        
                                        //Dependant Varible - Changes With Direction (Est. 3/18/21)
                                        CharacterPlacement = 6
                                        
                                    } else {
                                        CharacterPlacement = 5
                                    }
                                
                                } else {
                                    //Middle Tile
                                    CharacterPlacement = 5
                                }
                      
                                if (NorthActiveTileSet == 1) && (xBoardEdge == -1 && yBoardEdge == 1)   {
                                    
                                    
                                        BombEquipped = true
                                    
                                } else if (NorthActiveTileSet == 3) && (xBoardEdge == -2 && yBoardEdge == 1)  {
                                    
                                        BombEquipped = true
                                    
                                } else if (WestActiveTileSet == 3) && (xBoardEdge == -1 && yBoardEdge == 0) {
                                    
                                        BombEquipped = true
                                    
                                } else if (WestActiveTileSet == 4) && (xBoardEdge == -1 && yBoardEdge == 0) {
                                    
                                        BombEquipped = true
                                    
                                } else if (NorthActiveTileSet == 4) && (xBoardEdge == -2 && yBoardEdge == 1) {
                                    
                                        BombEquipped = true
                                    
                                } else if (NorthActiveTileSet == 5) && (xBoardEdge == -1 && yBoardEdge == 2) {
                                    
                                    BombEquipped = true
                               
                                } else if (NorthActiveTileSet == 7) && (xBoardEdge == -1 && yBoardEdge == 1) {
                                
                                        BombEquipped = true
                                    
                                } else if (WestActiveTileSet == 7) && (xBoardEdge == -2 && yBoardEdge == 0)  {
                                    
                                        BombEquipped = true
                                    
                                }
                                 
                            
                                
                                LookSideways = true
                                //Direction of Player
                                FacingLeft = true
                                FacingUp = false
                                FacingDown = false
                               FacingRight = false
                                
                                
                        } else if CharacterPlacement == 4{
                                CharacterPlacement = 6
                           //MOVE CHARACTER OFF SCREEN
                                
                                
                                if xBoardEdge >= 1 || xBoardEdge <= 0 || xBoardEdge == 0{
                                xBoardEdge -= 1
                                yBoardEdge -= 0
                                }
                            }
                            
                        }) {
                            ZStack{
    
                                Image("Arrow.Movement")
                                 .rotationEffect(Angle(degrees: 180))
                                    .aspectRatio(contentMode: .fit)
                                    .scaleEffect(1.21)
                            
                            }
                        }
                }
                   
                
                    Circle()
                        .foregroundColor(Color.white)
                        .aspectRatio(contentMode: .fit)
                        .opacity(0.0)
                }
                VStack{
                    ZStack{
                        //UP
                        
                        Button(action: {
                            let impactLight = UIImpactFeedbackGenerator(style: .light)
                                impactLight.impactOccurred()
                            
                            if CharacterPlacement == 8 && TutorialComplete == false {
                                if (xBoardEdge == 1 && yBoardEdge == 1){
                                    if ChestOpen == false {
                                        CurrentScreen = 16
                                    }
                                }
                            }
                            
                            if xBoardEdge == 0 && yBoardEdge == 0 {
                                TutPart1 = true
                                }
                            if xBoardEdge == 1 && yBoardEdge == 0 {
                                TutPart2 = true
                                }

                            
                            //Has an Enemy Been Killed / Selected
                            if EnemyHasBeenChosen == false {
                                EnemyHasBeenChosen = true
                                EnemyLevel = EnemyValue
                            } else if EnemyHasBeenChosen == true {
                                EnemyHasBeenChosen = false
                            }
                            
                            if CharacterPlacement == 5 {
                          
                                if TutorialComplete == false {
                                    if xBoardEdge == 0 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 0 {
                                        if WallCracked == false {
                                            CharacterPlacement = 5
                                        } else {
                                            CharacterPlacement = 2
                                        }
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if TutorialComplete == true {
                                
                                //Spawn (X = 0 and Y = 0)
                                if xBoardEdge == 0 && yBoardEdge == 0 {
                                    if SouthActiveTileSet != 8 {
                                    CharacterPlacement = 2
                                    } else {
                                        CharacterPlacement = 5
                                    }
                                }
                                //UP (From Y = 1 and Greater)
                                if NorthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                    CharacterPlacement = 2
                                } else if xBoardEdge == 2 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -2 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                }
                                } else if NorthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        if WallCracked == false {
                                            CharacterPlacement = 5
                                        } else if WallCracked == true {
                                        CharacterPlacement = 2
                                        }
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 1 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    }  else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        if WallCracked == false {
                                            CharacterPlacement = 5
                                        } else if WallCracked == true {
                                        CharacterPlacement = 2
                                        }
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }  else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                      
                                    }
                                }
                                
                                //Right (X = 1 and Greater)
                                if EastActiveTileSet == 1 {
                                if xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 2 {
                                  if  xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 3 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 5 && yBoardEdge == 0 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 4 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 5 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 4 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 5 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 6 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 7 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 3 && yBoardEdge == 2 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 3 && yBoardEdge == 3 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 3 && yBoardEdge == 4 {
                                        if WallCracked == false {
                                            CharacterPlacement = 5
                                        } else if WallCracked == true {
                                            CharacterPlacement = 2
                                        }
                                        
                                    } else if xBoardEdge == 2 && yBoardEdge == 4 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 5 {
                                        CharacterPlacement = 5
                                    }
                                }
                                //Left (X = -1 and Lower)
                                if WestActiveTileSet == 1 {
                                if xBoardEdge == -1 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                    CharacterPlacement = 2
                                    }
                                } else if WestActiveTileSet == 2 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == 0 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == -3 && yBoardEdge == 1 {
                                        if WallCracked == false {
                                            CharacterPlacement = 5
                                        } else if WallCracked == true {
                                            CharacterPlacement = 2
                                        }
                                    } else if xBoardEdge == -4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 3 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 4 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 5 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    }
                                } else if WestActiveTileSet == 6 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 7 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                }
                                //Down ( Y = -1 and Lower)
                                if SouthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == -1 {
                                    CharacterPlacement = 2
                                } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 3 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                    CharacterPlacement = 2
                                    }
                                } else if SouthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -3 {
                                        CharacterPlacement = 2
                                    }
                                } else if SouthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                       CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -3 {
                                        CharacterPlacement = 2
                                    }
                                } else if SouthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                        CharacterPlacement = 2
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                     CharacterPlacement = 2
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 2
                                    }
                                } else if SouthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    }
                                } else if SouthActiveTileSet == 8 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 2
                                    }
                                }
                            }
                                
                         } else if CharacterPlacement == 8 {
                                
                            if CurrentDungeon == 2 {
                                if (WaterWalking == false) && ((xBoardEdge == 1 && yBoardEdge == 1 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 5) || (xBoardEdge == 3 && yBoardEdge == 0 && EastActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == 0 && EastActiveTileSet == 5) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 6) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == 3 && EastActiveTileSet == 7) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 1) || (xBoardEdge == 3 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 2 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == -2 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 5) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 3) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 5) || (xBoardEdge == 0 && yBoardEdge == -1 && SouthActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == -1 && EastActiveTileSet == 3) || (xBoardEdge == 2 && yBoardEdge == 0 && NorthActiveTileSet == 2)) {
                                    
                                    //Dependant Varible - Changes With Direction (Est. 3/18/21)
                                    CharacterPlacement = 8
                                    
                                } else {
                                    CharacterPlacement = 5
                                }
                            
                            } else {
                                //Middle Tile
                                CharacterPlacement = 5
                            }
                            
                                
                                if NorthActiveTileSet == 3 || NorthActiveTileSet == 7 || EastActiveTileSet == 7 {
                                    if (xBoardEdge == 0 && yBoardEdge == 2) && (NorthActiveTileSet == 3 || NorthActiveTileSet == 7) {
                                        if ChestOpen == false {
                                            CurrentScreen = 16
                                        }
                                    } else if xBoardEdge == 3 && yBoardEdge == 5 {
                                        if EastActiveTileSet == 7 {
                                            if ChestOpen == false {
                                                CurrentScreen = 16
                                            }
                                        }
                                    }
                                }
                            
                                if xBoardEdge == -3 && yBoardEdge == 2 {
                                   if WestActiveTileSet == 2 {
                                       if ChestOpen == false {
                                           CurrentScreen = 16
                                       }
                                   }
                               }
                                
                                LookSideways = false
                                
                                FacingUp = true
                             FacingLeft = false
                            FacingDown = false
                           FacingRight = false
                            } else if CharacterPlacement == 2{
                          // NEW PART OF BOARD AKA NEW TILES.
                                CharacterPlacement = 8
                                
                                
                                if yBoardEdge <= -1 || yBoardEdge == 0 || yBoardEdge >= -1 {
                                xBoardEdge -= 0
                                yBoardEdge += 1
                                }
                                    
                            }
                        }) {
                            ZStack {
                            
                   
                            Image("Arrow.Movement")
                             .rotationEffect(Angle(degrees: 270))
                                .aspectRatio(contentMode: .fit)
                                .scaleEffect(1.21)
                           
                            }
                        }
                }
                    Circle()
                        .aspectRatio(contentMode: .fit)
                        .opacity(0.0)
                        
                        

                    ZStack{
                        //DOWN
                        Button(action: {
                            
                            let impactLight = UIImpactFeedbackGenerator(style: .light)
                                impactLight.impactOccurred()
                            
                            if xBoardEdge == 0 && yBoardEdge == 0 {
                                TutPart1 = true
                                }
                            if xBoardEdge == 1 && yBoardEdge == 0 {
                                TutPart2 = true
                                }

                            
                            //Action of Button Press)
                            
                            //Has an Enemy Been Killed / Selected
                            if EnemyHasBeenChosen == false {
                                EnemyHasBeenChosen = true
                                EnemyLevel = EnemyValue
                            } else if EnemyHasBeenChosen == true {
                                EnemyHasBeenChosen = false
                            }
                            
                            
                            if CharacterPlacement == 5{
                                if TutorialComplete == false {
                                    if xBoardEdge == 0 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    }
                                } else if TutorialComplete == true {
                                
                                //Spawn (X = 0 and Y = 0)
                                if xBoardEdge == 0 && yBoardEdge == 0 {
                                    if SouthActiveTileSet != 8 {
                                   CharacterPlacement = 8
                                    } else {
                                        CharacterPlacement = 8
                                    }
                                }
                                //UP (From Y = 1 and Greater)
                                if NorthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == 1 {
                                    CharacterPlacement = 8
                                } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 2 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                    CharacterPlacement = 8
                                } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -2 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                }
                                } else if NorthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    }
                                } else if NorthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 1 && yBoardEdge == 3 {
                                        CharacterPlacement = 8
                                    }  else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    }
                                } else if NorthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    }
                                }
                                
                                //Right (X = 1 and Greater)
                                if EastActiveTileSet == 1 {
                                if xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 2 {
                                  if  xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 3 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 5 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 5 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    }
                                } else if EastActiveTileSet == 4 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 5 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 6 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    }
                                } else if EastActiveTileSet == 7 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 3 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 3 && yBoardEdge == 3 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 3 && yBoardEdge == 4 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 2 && yBoardEdge == 4 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 5 {
                                        CharacterPlacement = 8
                                    }
                                }
                                //Left (X = -1 and Lower)
                                if WestActiveTileSet == 1 {
                                if xBoardEdge == -1 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                    CharacterPlacement = 8
                                } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 2 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == 0 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == 1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == 2 {
                                        CharacterPlacement = 8
                                    }
                                } else if WestActiveTileSet == 3 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 4 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 5 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 6 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 7 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                }
                                //Down ( Y = -1 and Lower)
                                if SouthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                    CharacterPlacement = 8
                                } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 3 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                    CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 2 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -1 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 8
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 8 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                }
                            }
                                
                                
                            } else if CharacterPlacement == 8{
                                // NEW PART OF BOARD AKA NEW TILES.
                                CharacterPlacement = 2
                           
                                //Random Tile Generator (Section)
                                //For The x,y Board. DO +1 Compared To What You Need
                                
                                if yBoardEdge == 0 || yBoardEdge != 0 {
                                xBoardEdge -= 0
                                yBoardEdge -= 1
                                }

                                
                            } else if CharacterPlacement == 2 {
                                
                                if CurrentDungeon == 2 {
                                    if (WaterWalking == false) && ((xBoardEdge == 1 && yBoardEdge == 1 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 5) || (xBoardEdge == 3 && yBoardEdge == 0 && EastActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == 0 && EastActiveTileSet == 5) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 6) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == 3 && EastActiveTileSet == 7) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 1) || (xBoardEdge == 3 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 2 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == -2 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 5) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 3) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 5) || (xBoardEdge == 0 && yBoardEdge == -1 && SouthActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == -1 && EastActiveTileSet == 3) || (xBoardEdge == 2 && yBoardEdge == 0 && NorthActiveTileSet == 2)) {
                                        
                                        //Dependant Varible - Changes With Direction (Est. 3/18/21)
                                        CharacterPlacement = 2
                                        
                                        
                                    } else {
                                        CharacterPlacement = 5
                                    }
                                
                                } else {
                                    //Middle Tile
                                    CharacterPlacement = 5
                                }
                                
                                LookSideways = false
                                
                                FacingUp = false
                             FacingLeft = false
                            FacingDown = true
                           FacingRight = false
                            }
                        }) {
                            ZStack{
                            //Image of Button
                        
                            Image("Arrow.Movement")
                                .rotationEffect(Angle(degrees: 90))
                                .aspectRatio(contentMode: .fit)
                                .scaleEffect(1.21)

                                
                        }
                    }
                }
            }
                VStack{
                        Button(action: {
                            //Button Action
                            if (BombEquipped == true && CharacterPlacement == 5) {
                                //Break Wall.
                                if NorthActiveTileSet == 3 || NorthActiveTileSet == 7 || EastActiveTileSet == 7 {
                                    if (xBoardEdge == 0 && yBoardEdge == 1) || (xBoardEdge == 3 && yBoardEdge == 4) {
                                        if BombUsed == false {
                                        WallCracked = true
                                        BombUsed = true
                                        }
                                    }
                                }
                                if WestActiveTileSet == 2 {
                                    if xBoardEdge == -3 && yBoardEdge == 1 {
                                        if BombUsed == false {
                                            WallCracked = true
                                            BombUsed = true
                                        }
                                    }
                                }
                                if TutorialComplete == false {
                                    if (xBoardEdge == 1 && yBoardEdge == 0) && BombUsed == false {
                                        WallCracked = true
                                        BombUsed = true
                                    }
                                }
                            }
                        }) {
                            ZStack{
                        Circle()
                            .foregroundColor(Color.white)
                            .aspectRatio(contentMode: .fit)
                            .opacity(1.0)
                                Image("Button.Use")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .edgesIgnoringSafeArea(.all)
                                    .scaleEffect(1.0497)
                                //.font(.custom("Helvetica Neue", size: 25))
                        }
                    }
                    
                    
                    //RIGHT
                    ZStack{
                        Button(action: {
                            
                            let impactLight = UIImpactFeedbackGenerator(style: .light)
                                impactLight.impactOccurred()
                        if xBoardEdge == 0 && yBoardEdge == 0 {
                            TutPart1 = true
                            }
                        if xBoardEdge == 1 && yBoardEdge == 0 {
                            TutPart2 = true
                            }
                            //Has an Enemy Been Killed / Selected
                            if EnemyHasBeenChosen == false {
                                EnemyHasBeenChosen = true
                                EnemyLevel = EnemyValue
                            } else if EnemyHasBeenChosen == true {
                                EnemyHasBeenChosen = false
                            }
                            
                            
                            if CharacterPlacement == 5 {
                                if TutorialComplete == false {
                                    if xBoardEdge == 0 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if TutorialComplete == true {
                                
                                //Spawn (X = 0 and Y = 0)
                                if xBoardEdge == 0 && yBoardEdge == 0 {
                                    if SouthActiveTileSet != 8 {
                                        CharacterPlacement = 6
                                    } else {
                                       CharacterPlacement = 5
                                    }
                                }
                                //UP (From Y = 1 and Greater)
                                if NorthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == 1 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 2 && yBoardEdge == 1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == -2 && yBoardEdge == 2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                    CharacterPlacement = 6
                                }  else if xBoardEdge == -2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                }
                                } else if NorthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    }
                                } else if NorthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                       CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == 2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    }  else if xBoardEdge == 2 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                } else if NorthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == 1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    }
                                }
                                
                                //Right (X = 1 and Greater)
                                if EastActiveTileSet == 1 {
                                if xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                    CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 2 {
                                  if  xBoardEdge == 1 && yBoardEdge == 0 {
                                    CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 3 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 5 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 5 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                    
                                } else if EastActiveTileSet == 4 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 5 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 6 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if EastActiveTileSet == 7 {
                                    if xBoardEdge == 1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 3 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 4 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 3 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 3 && yBoardEdge == 4 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == 4 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 4 && yBoardEdge == 3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 3 && yBoardEdge == 5 {
                                        CharacterPlacement = 5
                                    }
                                }
                                //Left (X = -1 and Lower)
                                if WestActiveTileSet == 1 {
                                if xBoardEdge == -1 && yBoardEdge == 0 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 2 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -3 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -3 && yBoardEdge == -1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -3 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -4 && yBoardEdge == 1 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 3 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    }
                                } else if WestActiveTileSet == 4 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    }
                                } else if WestActiveTileSet == 5 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 6 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 5
                                    }
                                } else if WestActiveTileSet == 7 {
                                    if xBoardEdge == -1 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -2 && yBoardEdge == 0 {
                                        CharacterPlacement = 6
                                    }
                                }
                                //Down ( Y = -1 and Lower)
                                if SouthActiveTileSet == 1 {
                                if xBoardEdge == 0 && yBoardEdge == -1 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                    CharacterPlacement = 6
                                } else if xBoardEdge == 3 && yBoardEdge == -1 {
                                    CharacterPlacement = 5
                                } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                    CharacterPlacement = 6
                                    }
                                } else if SouthActiveTileSet == 2 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 2 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 2 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 3 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 4 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 0 && yBoardEdge == -3 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == -1 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 1 && yBoardEdge == -3 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 5 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -1 && yBoardEdge == -1 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == -1 && yBoardEdge == -2 {
                                        CharacterPlacement = 6
                                    } else if xBoardEdge == 1 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 6 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    } else if xBoardEdge == 0 && yBoardEdge == -2 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 7 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                } else if SouthActiveTileSet == 8 {
                                    if xBoardEdge == 0 && yBoardEdge == -1 {
                                        CharacterPlacement = 5
                                    }
                                }
                            }
                                
                         } else if CharacterPlacement == 4 {
                            if CurrentDungeon == 2 {
                                if (WaterWalking == false) && ((xBoardEdge == 1 && yBoardEdge == 1 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 2) || (xBoardEdge == 2 && yBoardEdge == 2 && NorthActiveTileSet == 5) || (xBoardEdge == 3 && yBoardEdge == 0 && EastActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == 0 && EastActiveTileSet == 5) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 6) || (xBoardEdge == 4 && yBoardEdge == 0 && EastActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == 3 && EastActiveTileSet == 7) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 1) || (xBoardEdge == 3 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 2 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 4) || (xBoardEdge == 1 && yBoardEdge == -2 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 1) || (xBoardEdge == -2 && yBoardEdge == -1 && WestActiveTileSet == 5) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 1) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 2) || (xBoardEdge == 0 && yBoardEdge == -2 && SouthActiveTileSet == 3) || (xBoardEdge == -1 && yBoardEdge == -1 && SouthActiveTileSet == 5) || (xBoardEdge == 1 && yBoardEdge == -1 && SouthActiveTileSet == 2) || (xBoardEdge == -2 && yBoardEdge == 0 && WestActiveTileSet == 5) || (xBoardEdge == 0 && yBoardEdge == -1 && SouthActiveTileSet == 7) || (xBoardEdge == 4 && yBoardEdge == -1 && EastActiveTileSet == 3) || (xBoardEdge == 2 && yBoardEdge == 0 && NorthActiveTileSet == 2)) {
                                    
                                    //Dependant Varible - Changes With Direction (Est. 3/18/21)
                                    CharacterPlacement = 4
                                    
                                } else {
                                    CharacterPlacement = 5
                                }
                            
                            } else {
                                //Middle Tile
                                CharacterPlacement = 5
                            }
                            
                            if (TutorialComplete == false) && (xBoardEdge == 1 && yBoardEdge == 0) {
                                BombEquipped = true
                            }
                                
                            LookSideways = true
                                
                                FacingUp = false
                             FacingLeft = false
                            FacingDown = false
                           FacingRight = true
                            } else if CharacterPlacement == 6{
                          // NEW PART OF BOARD AKA NEW TILES.
                                
                                CharacterPlacement = 4
                                
                                
                                if xBoardEdge >= -1 || xBoardEdge <= -1 {
                                xBoardEdge += 1
                                yBoardEdge -= 0
                                } else if xBoardEdge == 0 {
                                    xBoardEdge += 1
                                    yBoardEdge -= 0
                                }

                            }
                        }) {
                        //RIGHT
                            ZStack {
                     
                        Image("Arrow.Movement")
                         .rotationEffect(Angle(degrees: 0))
                            .aspectRatio(contentMode: .fit)
                            .scaleEffect(1.21)
                            }
                        }

                }

                    Circle()
                        .foregroundColor(Color.white)
                        .aspectRatio(contentMode: .fit)
                        .opacity(0.0)

                    
                    }
                }
            Spacer__()
            }
        }
    }
}
struct Play_Previews: PreviewProvider {
    static var previews: some View {
        Play()
    }
}


