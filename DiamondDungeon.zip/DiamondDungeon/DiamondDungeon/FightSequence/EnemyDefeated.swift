//
//  EnemyDefeated.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/8/20.
//

import SwiftUI

struct EnemyDefeated: View {
    @AppStorage ("AttackButtonPushed") var AttackButtonPushed = false
    @AppStorage ("CheckAttackHero") var CheckAttackHero = false
    @AppStorage ("CheckAttackEnemy") var CheckAttackEnemy = false
    
    //Currency
    @AppStorage ("SkillOrbs") var SkillOrbs = 0
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeated7") var EnemyDefeated7 = 0
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    
    @AppStorage ("EnemyDefeatedBoss") var EnemyDefeatedBoss = 0
    
    @AppStorage ("Coin") var Coins = 0
    @AppStorage ("RAE") var randomAmountEarned = Int.random(in: 5..<20)
    
    var body: some View {
    ZStack{
        Rectangle()
            .foregroundColor(Color(red: 14/255, green: 194/255, blue: 252/255))
            .edgesIgnoringSafeArea(.all)
        Rectangle()
            .foregroundColor(Color.white)
            .rotationEffect(Angle(degrees: 45))
            .scaleEffect(1.15)
            .opacity(0.5)
    
        VStack{
            Spacer()
            Text("Enemy Defeated")
                .foregroundColor(Color.black)
                .bold()
                .font(.system(size: 48))
            Spacer()
            Text("Resources Found")
                .underline()
                .bold()
            
            Text("Coins Earned: +" + String(randomAmountEarned))
                .bold()

            Text("Wood x1")     //Don't Hard Code
                .bold()
            Text("Stone x1")    //Don't Hard Code
                .bold()
            
            if EnemyDefeatedBoss == 1 {
                Text("Skill Orb x1")
                    .bold()
            }
            
        Spacer__()
            
            Button(action: {
                CheckAttackHero = false
                CheckAttackEnemy = false
                AttackButtonPushed = false
                
                if EnemyDefeated1 == 1 {
                    EnemyDefeated1 = 2
                    CurrentScreen = 6
                }else if EnemyDefeated2 == 1 {
                    EnemyDefeated2 = 2
                    CurrentScreen = 6
                }else if EnemyDefeated3 == 1 {
                    EnemyDefeated3 = 2
                    CurrentScreen = 6
                }else if EnemyDefeated4 == 1 {
                    EnemyDefeated4 = 2
                    CurrentScreen = 6
                }else if EnemyDefeated5 == 1 {
                    EnemyDefeated5 = 2
                    CurrentScreen = 6
                }else if EnemyDefeated6 == 1 {
                    EnemyDefeated6 = 2
                    CurrentScreen = 6
                }else if EnemyDefeated7 == 1 {
                    EnemyDefeated7 = 2
                    CurrentScreen = 6
                }else if EnemyDefeatedBoss == 1 {
                    EnemyDefeatedBoss = 2
                }
                
                if EnemyDefeatedBoss == 2 {
                    CurrentScreen = 1
                    SkillOrbs += 1
                }
                Coins += randomAmountEarned

            }) {
                Text("Continue")
                    .bold()
                    .foregroundColor(Color.black)
                    .padding(.all, 18)
                    .padding([.leading, .trailing], 30)
                    .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                    .cornerRadius(20)

                    
                }
            }
        }
    }
}

struct EnemyDefeated_Previews: PreviewProvider {
    static var previews: some View {
        EnemyDefeated()
    }
}
