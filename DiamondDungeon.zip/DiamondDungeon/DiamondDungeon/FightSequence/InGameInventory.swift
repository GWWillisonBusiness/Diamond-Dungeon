//
//  InGameInventory.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 2/24/21.
//

import SwiftUI

struct InGameInventory: View {
    
    @AppStorage ("BombEquipped") var BombEquipped = false
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        ZStack{
            
        Rectangle()
            .foregroundColor(.green)
            .edgesIgnoringSafeArea(.all)
            .opacity(0.36)
        Rectangle()
            .foregroundColor(.blue)
            .edgesIgnoringSafeArea(.all)
            .opacity(0.14)
        
        ScrollViewReader { scrollView in
            ScrollView {
                //HEADER - TOP OF VIEW
                    ZStack {
                        VStack{
                            Spacer()
                    Text("IN GAME INVENTORY")
                            Spacer()
                    Button(action: {
                        CurrentScreen = 6
                    }) {

                        Text("EXIT")
                            .bold()
                            .foregroundColor(Color.red)
                            .padding(.all, 18)
                            .padding([.leading, .trailing], 30)
                            .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                            .cornerRadius(20)
                    
                    }
                HStack {
                    VStack {
                        ZStack {
                    LittleSquare()
                            if BombEquipped == true {
                                Image("Game.Bomb")
                                    .aspectRatio(contentMode: .fit)
                                    .edgesIgnoringSafeArea(.all)
                            }
                        }
                    LittleSquare()
                    LittleSquare()
                    LittleSquare()
                    LittleSquare()
                    LittleSquare()
                    LittleSquare()
                    LittleSquare()
                                        }
                    VStack {
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                    }
                    VStack {
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                        LittleSquare()
                    }
                                    }
                        }
                    }
                }
            }
        }
    }
}

struct InGameInventory_Previews: PreviewProvider {
    static var previews: some View {
        InGameInventory()
    }
}
