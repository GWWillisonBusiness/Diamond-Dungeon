//
//  BattleWinButton.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/6/20.
//
// Currently InActive

import SwiftUI

struct BattleWinButton: View {
    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    var body: some View {
        
        Button(action: {
            CurrentScreen = 6
            if EnemyDefeated1 == 1 {
            EnemyDefeated1 = 2
            } else if EnemyDefeated2 == 1 {
            EnemyDefeated2 = 2
            } else if EnemyDefeated3 == 1 {
                EnemyDefeated2 = 2
            } else if EnemyDefeated4 == 1 {
                EnemyDefeated2 = 2
            } else if EnemyDefeated5 == 1 {
                EnemyDefeated2 = 2
            } else if EnemyDefeated6 == 1 {
                EnemyDefeated2 = 2
            }
        }) {
            Text("Continue // Won Battle")
                .bold()
                .foregroundColor(Color.white)
        }
    }
}

struct BattleWinButton_Previews: PreviewProvider {
    static var previews: some View {
        BattleWinButton()
    }
}
