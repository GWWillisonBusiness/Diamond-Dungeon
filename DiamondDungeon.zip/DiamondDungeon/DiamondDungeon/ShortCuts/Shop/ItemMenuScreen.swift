//
//  ItemMenuScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/18/21.
//

import SwiftUI

struct ItemMenuScreen: View {
    
    @AppStorage ("FlameSpearPurchase") var FlameSpearPurchase = false
    @AppStorage ("FlameSpearScreen") var FlameSpearScreen = false
    @AppStorage ("FlameSpearMenuScreen") var FlameSpearMenuScreen = false

    //System of Currency ---------------------------
    @AppStorage ("Coin")    var Coins = 0
    @AppStorage ("Diamond")  var Diamond = 0
    //----------------------------------------------
    
    @AppStorage ("FlameSpearWeaponScreenActive") var FlameSpearWeaponScreenActive = false
    @AppStorage ("IronSwordWeaponScreenActive") var IronSwordWeaponScreenActive = false
    
    @AppStorage ("IronSwordMenuScreen") var IronSwordMenuScreen = false
    @AppStorage ("IronSwordScreen") var IronSwordScreen = false
    @AppStorage ("IronSwordPurchase") var IronSwordPurchase = false
    
    var body: some View {
        Rectangle()
            .foregroundColor(Color.gray)
            .aspectRatio(contentMode: .fit)
            .cornerRadius(20)
            VStack {
            HStack {
                ZStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                    Image("BackArrow")
                    Button("                  "){
                        FlameSpearMenuScreen = false
                        IronSwordMenuScreen = false
                        FlameSpearWeaponScreenActive = false
                        IronSwordWeaponScreenActive = false
                    }
                }//ZStack
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
                HStack {
                    ZStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//ZStack
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                HStack {
                    ZStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//ZStack
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                HStack {
                    ZStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//ZStack
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
            }//VStack
        
        if IronSwordWeaponScreenActive == true {
            VStack {
            HStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                ZStack {
                    //Top Row, Middle Column
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                    
                        Image("Sword.Iron")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                }
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
            HStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
            HStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
            }//VStack
            
            VStack {
                Spacer()
                Spacer()
                Text("Iron Sword")
                    .font(.system(size: 24))
                    .bold()
                Text("+2 Damage")
                    .bold()
                HStack {
                Text("500")
                Image("Coin")
                } // HStack
                            Button(action: {
                                //Button Press...
                                if Coins > 500 && IronSwordPurchase == false  {
                                    IronSwordPurchase = true
                                    Coins -= 500
                                    IronSwordMenuScreen = false
                                }
                            } ) {
                                if IronSwordPurchase == false {
                             Text("Purchase")
                                .bold()
                                .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                                } else if IronSwordPurchase == true {
                                Text("Purchased")
                                .bold()
                                .foregroundColor(Color(red: 255/255, green: 0/255, blue: 0/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                                }
                            }
                    Text("Common Rarity")
                        .foregroundColor(Color.white)
                Spacer()
            } //VStack
            
        } // If Statement
        if FlameSpearWeaponScreenActive == true {
            VStack {
             HStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                ZStack {
                    //Top Row, Middle Column
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                    
                        Image("Sword.FlameSpear")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                }
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
            HStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
            HStack {
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                Rectangle()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                    .opacity(0.0)
                }//HStack
            }//VStack
            
            VStack {
                Spacer()
                Spacer()
                Text("Flame Spear")
                    .font(.system(size: 24))
                    .bold()
                Text("+5 Damage")
                    .bold()
                HStack {
                Text("2500")
                Image("Coin")
                } // HStack
                            Button(action: {
                                //Button Press...
                                if Coins > 2500 && FlameSpearPurchase == false  {
                                    FlameSpearPurchase = true
                                    Coins -= 2500
                                    FlameSpearMenuScreen = false
                                }
                            } ) {
                                if FlameSpearPurchase == false {
                             Text("Purchase")
                                .bold()
                                .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                                } else if FlameSpearPurchase == true {
                                Text("Purchased")
                                .bold()
                                .foregroundColor(Color(red: 255/255, green: 0/255, blue: 0/255))
                                .padding(.all, 18)
                                .padding([.leading, .trailing], 30)
                                .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                .cornerRadius(20)
                                }
                            }
                    Text("Un-Common Rarity")
                        .foregroundColor(Color(red: 100/255, green: 30/255, blue: 255/255))
                        .bold()
                Spacer()
            } //VStack
            
        } // If Statement
    }
}

struct ItemMenuScreen_Previews: PreviewProvider {
    static var previews: some View {
        ItemMenuScreen()
    }
}
