//
//  ShopInfo.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/17/21.
//

import SwiftUI

struct ShopInfo: View {
    // The Value of The Crate Helps Determine: Animation, and Location
    @AppStorage ("WoodenCrateValue") var WoodenCrateValue = 0
    @AppStorage ("CrateScreen") var CrateScreen = false
    
    let timing = 0.05
    
    @AppStorage ("FlameSpearWeaponScreenActive") var FlameSpearWeaponScreenActive = false
    @AppStorage ("IronSwordWeaponScreenActive") var IronSwordWeaponScreenActive = false
    
    @AppStorage ("IronSwordMenuScreen") var IronSwordMenuScreen = false
    @AppStorage ("IronSwordScreen") var IronSwordScreen = false
    @AppStorage ("IronSwordPurchase") var IronSwordPurchase = false
    
    @AppStorage ("FlameSpearMenuScreen") var FlameSpearMenuScreen = false
    @AppStorage ("FlameSpearPurchase") var FlameSpearPurchase = false
    @AppStorage ("FlameSpearScreen") var FlameSpearScreen = false
    var body: some View {
        VStack {
            Text("Weapons")
                .bold()
            HStack {
            
            //Top Left #1
            ZStack {
         
                Button(action: {
                    if IronSwordPurchase == false {
                    IronSwordMenuScreen = true
                    IronSwordWeaponScreenActive = true
                    }
                } ) {
                    ZStack {
                        if IronSwordPurchase == false {
                        Rectangle()
                        .foregroundColor(Color.gray)
                            .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                        .cornerRadius(20)
                        } else if IronSwordPurchase == true {
                            Rectangle()
                            .foregroundColor(Color.green)
                                .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(20)
                        }
                            Image("Sword.Iron")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                    }
                }
            
            //Top Middle #2
                ZStack {
             
                    Button(action: {
                        if FlameSpearPurchase == false {
                        FlameSpearMenuScreen = true
                        FlameSpearWeaponScreenActive = true
                        }
                    } ) {
                        ZStack {
                            if FlameSpearPurchase == false {
                            Rectangle()
                            .foregroundColor(Color.gray)
                                .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(20)
                            } else if FlameSpearPurchase == true {
                                Rectangle()
                                .foregroundColor(Color.green)
                                    .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                                .cornerRadius(20)
                            }
                                Image("Sword.FlameSpear")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }
                        }
                    }
            
            //Top Right #3
                ZStack {
            Rectangle()
            .foregroundColor(Color.gray)
                .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
            .cornerRadius(20)
                }
        }//HStack
            Text("Items")
                .bold()
            HStack {
                
                //Middle Left #4
                ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                }
                
                //Middle Middle #5
                    ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                    }
                
                //Middle Right #6
                        ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                        }
            }//HStack
            Text("Crates")
                .bold()
            
            HStack{
                //Crates (Needs Work. As of: 1/18/2021)
                //Bottom Left #7
                ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                }
                
                //Bottom Middle #8
                    ZStack {
                        Rectangle()
                        .foregroundColor(Color.gray)
                            .aspectRatio(contentMode: .fit)
                        .edgesIgnoringSafeArea(.all)
                        .cornerRadius(20)
                        ZStack{
                            Button(action: {
                               
                                
                                if WoodenCrateValue == 0 {
                                    WoodenCrateValue = 1
                                }
                                if WoodenCrateValue != 0 {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + timing){
                                        WoodenCrateValue = 2
                                        DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                            WoodenCrateValue = 3
                                            DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                WoodenCrateValue = 4
                                                DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                    WoodenCrateValue = 5
                                                    DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                        WoodenCrateValue = 6
                                                        DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                            WoodenCrateValue = 7
                                                            DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                WoodenCrateValue = 8
                                                                DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                    WoodenCrateValue = 9
                                                                    DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                        WoodenCrateValue = 10
                                                                        DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                            WoodenCrateValue = 11
                                                                            DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                                WoodenCrateValue = 12
                                                                                DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                                    WoodenCrateValue = 13
                                                                                    DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                                        WoodenCrateValue = 14
                                                                                        DispatchQueue.main.asyncAfter(deadline: .now() + timing) {
                                                                                            CrateScreen = true
                                                                                            WoodenCrateValue = 0
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }){
                            if WoodenCrateValue == 0 {
                Image("Crate.Wooden")
                    .aspectRatio(1, contentMode: .fit)
                            }
                            if WoodenCrateValue == 1 {
                                Image("Crate.Wooden")
                                    .aspectRatio(1, contentMode: .fit)
                                    .offset(x: 0, y: -20)
                                }
                                if WoodenCrateValue == 2 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -40)
                                    }
                                if WoodenCrateValue == 3 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -65)
                                    }
                                if WoodenCrateValue == 4 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -90)
                                    }
                                if WoodenCrateValue == 5 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -120)
                                    }
                                if WoodenCrateValue == 6 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -160)
                                    }
                                if WoodenCrateValue == 7 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -205)
                                    }

                                if WoodenCrateValue == 8 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -250)
                                    }
                                if 1 == 1 {
                                if WoodenCrateValue == 9 {
                                    Image("Crate.Wooden")
                                        .aspectRatio(1, contentMode: .fit)
                                        .offset(x: 0, y: -300)
                                    }
                                    if WoodenCrateValue == 10 {
                                        Image("Crate.Wooden")
                                            .aspectRatio(1, contentMode: .fit)
                                            .offset(x: 0, y: -360)
                                        }
                                    if WoodenCrateValue == 11 {
                                        Image("Crate.Wooden")
                                            .aspectRatio(1, contentMode: .fit)
                                            .offset(x: 0, y: -410)
                                        }
                                    if WoodenCrateValue == 12 {
                                        Image("Crate.Wooden")
                                            .aspectRatio(1, contentMode: .fit)
                                            .offset(x: 0, y: -460)
                                        }
                                    if WoodenCrateValue == 13 {
                                        Image("Crate.Wooden")
                                            .aspectRatio(1, contentMode: .fit)
                                            .offset(x: 0, y: -520)
                                        }
                                    if WoodenCrateValue == 14 {
                                        Image("Crate.Wooden")
                                            .aspectRatio(1, contentMode: .fit)
                                            .offset(x: 0, y: -6000)
                                        }
                                }
                           
                            }
                        }
                    }
                
                //Bottom Right #9
                        ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                        }
            }
   
        }//VStack
        if IronSwordMenuScreen == true || FlameSpearMenuScreen == true {
            ItemMenuScreen()
        }// If Statement
    }
}

struct ShopInfo_Previews: PreviewProvider {
    static var previews: some View {
        ShopInfo()
    }
}
