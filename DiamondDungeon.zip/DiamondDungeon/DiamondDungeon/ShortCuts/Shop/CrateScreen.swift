//
//  CrateScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 5/22/21.
//

import SwiftUI

struct CrateScreen: View {
    @AppStorage ("CrateScreen") var CrateScreen = false
    @State var WoodenCrateValue = 0
    
    var body: some View {
        VStack {
           Spacer10()
            
            Text("LOOT INSIDE CRATE ( UNDER DEV )")
                .bold()
                .font(.system(size: 27))
                .foregroundColor(.gray)
            
            
           Spacer10()
           Spacer10()
            
            
        Button(action: {
            CrateScreen = false
        }) {
            Image("Crate.Wooden")
                .aspectRatio(1, contentMode: .fit)
                .offset(x: 0, y: 0)
            }
            
        }
    }
}

struct CrateScreen_Previews: PreviewProvider {
    static var previews: some View {
        CrateScreen()
    }
}
