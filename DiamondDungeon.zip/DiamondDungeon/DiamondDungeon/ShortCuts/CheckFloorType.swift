//
//  CheckFloorType.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/25/21.
//

import SwiftUI

struct CheckFloorType: View {
    @AppStorage ("CheckTile") var CheckTile = 0
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    var body: some View {
        if  CurrentDungeon == 1 {
            if CheckTile == 1 || CheckTile == 2 {
        Image("Floor.Sand")
            .resizable()
        .foregroundColor(Color.blue)
    .aspectRatio(contentMode: .fit)
    .edgesIgnoringSafeArea(.all)
        .cornerRadius(5)
            } else if CheckTile == 3{
                Image("Floor.Grass")
                    .resizable()
                .foregroundColor(Color.blue)
            .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
                .cornerRadius(5)
            }
        } else if CurrentDungeon == 2 {
            Image("Floor.Sand2")
                .resizable()
            .foregroundColor(Color.blue)
        .aspectRatio(contentMode: .fit)
        .edgesIgnoringSafeArea(.all)
            .cornerRadius(5)
        } else if CurrentDungeon == 3 {
            Image("Floor.Seaweed")
                .resizable()
            .foregroundColor(Color.blue)
        .aspectRatio(contentMode: .fit)
        .edgesIgnoringSafeArea(.all)
            .cornerRadius(5)
        }
    }
}

struct CheckFloorType_Previews: PreviewProvider {
    static var previews: some View {
        CheckFloorType()
    }
}
