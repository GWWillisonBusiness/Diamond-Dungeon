//
//  LittleSquare.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/26/20.
//

import SwiftUI

struct LittleSquare: View {
    var body: some View {
        
        Rectangle()
        .foregroundColor(Color.gray)
        .aspectRatio(contentMode: .fit)
        .edgesIgnoringSafeArea(.all)
        .cornerRadius(20)

    }
}

struct LittleSquare_Previews: PreviewProvider {
    static var previews: some View {
        LittleSquare()
    }
}
