//
//  bottomNavBar.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/28/20.
//

import SwiftUI

struct bottomNavBar: View {
    var body: some View {
        
        
        NavigationView{
            
            VStack{
                Text("Skills")
            
        HStack{
            ZStack{
                LittleSquare()
                NavigationLink(destination: Shop()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Shop")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Homescreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Inv")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Homescreen()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Play")
                    
                }

            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Clans()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Clans")
                    
                }
            }
            ZStack{
                LittleSquare()
                NavigationLink(destination: Skills()
                                .navigationTitle(Text(""))
                                .navigationBarHidden(true)){
                    Text("Skills")
                            }
                        }
                    }
            }
        }
    }
}
struct bottomNavBar_Previews: PreviewProvider {
    static var previews: some View {
        bottomNavBar()
    }
}
