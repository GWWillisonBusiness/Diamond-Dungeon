//
//  CharacterDirection.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/14/21.
//

import SwiftUI

struct CharacterDirection: View {
    
    //Direction of Player
    @AppStorage ("FacingUp") var FacingUp = false
    @AppStorage ("FacingLeft") var FacingLeft = false
    @AppStorage ("FacingDown") var FacingDown = false
    @AppStorage ("FacingRight") var FacingRight = false
    
    @AppStorage ("LookSideways") var LookSideways = false
    var body: some View {
    
        //Facing Up
        if LookSideways == true {
            Image("Hero.TDV")
            .scaleEffect(1.5)
                .rotationEffect(.degrees(90))
        } else {
            Image("Hero.TDV")
            .scaleEffect(1.5)
        }
    }
}

struct CharacterDirection_Previews: PreviewProvider {
    static var previews: some View {
        CharacterDirection()
    }
}
