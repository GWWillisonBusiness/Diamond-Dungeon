//
//  EnemySelect.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/16/21.
//
//Which Enemy To Select For Each Square

import SwiftUI

struct EnemySelect: View {
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    
    @AppStorage ("EnemyValue") var EnemyValue = Int.random(in: 1..<4)
    @AppStorage ("EnemyHasBeenChosen") var EnemyHasBeenChosen = false
    @AppStorage ("EnemyLevel") var EnemyLevel = 1
    
    @AppStorage ("CurrentEnemyHealth") var CurrentEnemyHealth = 4
    @AppStorage ("CurrentEnemyAttack") var CurrentEnemyAttack = 2
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    // 0 = Not Contacted Yet, 1 = Contacted, 2 = Defeated
    @AppStorage ("EnemyDefeated6") var EnemyDefeated6 = 0
    @AppStorage ("EnemyDefeated5") var EnemyDefeated5 = 0
    @AppStorage ("EnemyDefeated4") var EnemyDefeated4 = 0
    @AppStorage ("EnemyDefeated3") var EnemyDefeated3 = 0
    @AppStorage ("EnemyDefeated2") var EnemyDefeated2 = 0
    @AppStorage ("EnemyDefeated1") var EnemyDefeated1 = 0
    
    var body: some View {
        
     if CharacterPlacement == 5 && EnemyDefeated3 == 0 {
            ZStack{
                
              CheckFloorEnemy()
                
                VStack {
                    Text(" ENEMY ")
                        .bold()
                        .foregroundColor(Color.black)
                        .font(.system(size: 42))
                    Text("Level: " + String(EnemyLevel)) // Add Level var
                    ZStack{
                        Rectangle()
                            .frame(width: 1000, height: 5)
                        Button(action: {
                            
                            
                            
                            if EnemyLevel == 1 {
                             
                                CurrentEnemyAttack = 1
                                CurrentEnemyHealth = 3
                            } else if EnemyLevel == 2 {
                         
                                CurrentEnemyAttack = 2
                                CurrentEnemyHealth = 5
                            } else if EnemyLevel == 3 {
                                
                                CurrentEnemyAttack = 3
                                CurrentEnemyHealth = 8
                            }
                            
                            CurrentScreen = 9
                            EnemyDefeated3 = 1
                        }) {
                            ZStack {
                            Circle()
                                //.font(.system(size: 42))
                                .foregroundColor(Color.red)
                                .padding(.all, 20)
                                .frame(width: 200, height: 200)

                      
                          Text("FIGHT")
                            .bold()
                            .foregroundColor(Color.white)
                            .font(.system(size: 42))
                            }
                                
                       
                        }
                                }
                    Text(" YOU ")
                        .bold()
                        .foregroundColor(Color.black)
                        .font(.system(size: 42))
                    Text("Level: " + String(EnemyLevel)) // Add Level var
                        } //VStack
                }
            } else if CharacterPlacement != 5 && EnemyDefeated3 == 0 {
                if EnemyLevel == 1 {
                    Image("Enemy.NightBat")
                } else if EnemyLevel == 2 {
                    Image("Enemy.GreenGhost")
                } else if EnemyLevel == 3 {
                    Image("Enemy.SmallRedBlob")
                }
            } else if CharacterPlacement == 5 && EnemyDefeated3 == 2 {
                ZStack{
                   CheckFloorType2()

                    
                    CharacterDirection()
                    
                }
            } else if CharacterPlacement == 5 && EnemyDefeated3 == 1 {
                ZStack{
                    
                  CheckFloorType2()


                    CharacterDirection()

                }
            }
        }
    }


struct EnemySelect_Previews: PreviewProvider {
    static var previews: some View {
        EnemySelect()
    }
}
