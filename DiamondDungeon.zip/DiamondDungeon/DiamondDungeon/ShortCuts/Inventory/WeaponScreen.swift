//
//  WeaponScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/18/21.
//

import SwiftUI

struct WeaponScreen: View {
    @AppStorage ("DamageItemClicked") var DamageItemClicked = false
    
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("IronSwordEquipped") var IronSwordEquipped = false
    @AppStorage ("IronSwordWeaponScreenActive") var IronSwordWeaponScreenActive = false
    @AppStorage ("IronSwordPurchase") var IronSwordPurchase = false
    
    @AppStorage ("FlameSpearWeaponScreenActive") var FlameSpearWeaponScreenActive = false
    @AppStorage ("FlameSpearPurchase") var FlameSpearPurchase = false
    @AppStorage ("FlameSpearScreen") var FlameSpearScreen = false
    @AppStorage ("FlameSpearMenuScreen") var FlameSpearMenuScreen = false
    @AppStorage ("FlameSpearEquipped") var FlameSpearEquipped = false
    
    var body: some View {
            Rectangle()
                .foregroundColor(Color.gray)
                .aspectRatio(contentMode: .fit)
                .cornerRadius(20)
            VStack {
                HStack {
                    ZStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                        Image("BackArrow")
                        Button("                  "){
                            IronSwordWeaponScreenActive = false
                            FlameSpearWeaponScreenActive = false
                    
                            
                        } // Button
                    }//ZStack
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                    HStack {
                        ZStack {
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        }//ZStack
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        }//HStack
                    HStack {
                        ZStack {
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        }//ZStack
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        }//HStack
                    HStack {
                        ZStack {
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        }//ZStack
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        Rectangle()
                            .aspectRatio(contentMode: .fit)
                            .cornerRadius(20)
                            .opacity(0.0)
                        }//HStack
                }//VStack
        if IronSwordWeaponScreenActive == true {
            VStack {
                HStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    ZStack {
                        //Top Row, Middle Column
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                        
                            Image("Sword.Iron")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                    } //ZStack
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                HStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                HStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                }//VStack
                
                VStack {
                    Spacer()
                    Spacer()
                    Text("Iron Sword")
                        .font(.system(size: 24))
                        .bold()
                    Text("+2 Damage")
                        .bold()
                                Button(action: {
                                    //Button Press...
                                    if IronSwordEquipped == false {
                                        if FlameSpearEquipped == true {
                                        FlameSpearEquipped = false
                                            CurrentHeroAttack -= 5
                                            DamageItemClicked = true
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.125) {
                                             DamageItemClicked = false
                                            }
                                        }
                                        IronSwordEquipped = true
                                        CurrentHeroAttack += 2
                                        DamageItemClicked = true
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.125) {
                                         DamageItemClicked = false
                                        }

                                    } else if IronSwordEquipped == true {
                                        IronSwordEquipped = false
                                        CurrentHeroAttack -= 2
                                        DamageItemClicked = true
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.125) {
                                         DamageItemClicked = false
                                        }

                                    }
                                } ) {
                                    if IronSwordEquipped == false {
                                 Text("Equip")
                                    .bold()
                                    .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                    .padding(.all, 18)
                                    .padding([.leading, .trailing], 30)
                                    .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                    .cornerRadius(20)
                                    } else if IronSwordEquipped == true {
                                        Text("Unequip")
                                        .bold()
                                        .foregroundColor(Color(red: 255/255, green: 0/255, blue: 0/255))
                                        .padding(.all, 18)
                                        .padding([.leading, .trailing], 30)
                                        .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                        .cornerRadius(20)
                                    }
                                }
                        Text("Common Rarity")
                            .foregroundColor(Color.white)
                    Spacer()
                } //VStack
            } // If Statement
        
        if FlameSpearWeaponScreenActive == true {
            VStack {
                HStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    ZStack {
                        //Top Row, Middle Column
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                        
                            Image("Sword.FlameSpear")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                    } //ZStack
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                HStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                HStack {
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    Rectangle()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                        .opacity(0.0)
                    }//HStack
                }//VStack
                
                VStack {
                    Spacer()
                    Spacer()
                    Text("Flame Spear")
                        .font(.system(size: 24))
                        .bold()
                    Text("+5 Damage")
                        .bold()
                                Button(action: {
                                    //Button Press...
                                    if FlameSpearEquipped == false {
                                        if IronSwordEquipped == true {
                                            CurrentHeroAttack -= 2
                                            DamageItemClicked = true
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.125) {
                                             DamageItemClicked = false
                                            }

                                            IronSwordEquipped = false
                                        }
                                        FlameSpearEquipped = true
                                        CurrentHeroAttack += 5
                                        DamageItemClicked = true
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.125) {
                                         DamageItemClicked = false
                                        }

                                    } else if FlameSpearEquipped == true {
                                        FlameSpearEquipped = false
                                        CurrentHeroAttack -= 5
                                        DamageItemClicked = true
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.125) {
                                         DamageItemClicked = false
                                        }

                                    }
                                } ) {
                                    if FlameSpearEquipped == false {
                                 Text("Equip")
                                    .bold()
                                    .foregroundColor(Color(red: 95/255, green: 250/255, blue: 77/255))
                                    .padding(.all, 18)
                                    .padding([.leading, .trailing], 30)
                                    .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                    .cornerRadius(20)
                                    } else if FlameSpearEquipped == true {
                                        Text("Unequip")
                                        .bold()
                                        .foregroundColor(Color(red: 255/255, green: 0/255, blue: 0/255))
                                        .padding(.all, 18)
                                        .padding([.leading, .trailing], 30)
                                        .background(Color(red: 255/255, green: 255/255, blue: 255/255))
                                        .cornerRadius(20)
                                    }
                                }
                        Text("Un-Common Rarity")
                            .foregroundColor(Color.white)
                    Spacer()
                } //VStack
            } // If Statement
    }
}

struct WeaponScreen_Previews: PreviewProvider {
    static var previews: some View {
        WeaponScreen()
    }
}
