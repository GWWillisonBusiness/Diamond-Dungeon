//
//  ItemsInventoryScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 5/20/21.
//

import SwiftUI

struct ItemsInventoryScreen: View {
    var body: some View {
        //Work On Rings and Other Items To Increase Health. Base is 10. Maybe Change to 8
        Text("Hello, World!")
    }
}

struct ItemsInventoryScreen_Previews: PreviewProvider {
    static var previews: some View {
        ItemsInventoryScreen()
    }
}
