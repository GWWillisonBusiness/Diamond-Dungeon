//
//  InventoryCharacterInfo.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/30/21.
//

import SwiftUI

struct InventoryCharacterInfo: View {
    @AppStorage ("WeaponInventory") var WeaponInventory = false
    
    @AppStorage ("FlameSpearEquipped") var FlameSpearEquipped = false
    @AppStorage ("IronSwordEquipped") var IronSwordEquipped = false
    
    var body: some View {
        ZStack {
            Image("Hero.Basic")
                .aspectRatio(contentMode: .fit)
                .shadow(radius: 14)
            
        VStack{
            HStack{
                //Top Middle Square
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
            }
            HStack{
                //Top Left Square
                ZStack {
                LittleSquare()
                    Image("Item.HealthRing")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                Button(action: {
                    if WeaponInventory == false {
                    WeaponInventory = true
                    }
                }) {
                //Top Right Square
                    ZStack {
                LittleSquare()
                        if IronSwordEquipped == true {
                            Image("Sword.Iron")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        } else if FlameSpearEquipped == true {
                            Image("Sword.FlameSpear")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                    }
                }
            }
            
            HStack{
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
            }
            HStack{
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
            }
            HStack{
                //Bottom Left Square
                LittleSquare()
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                //Bottom Right Square
                LittleSquare()
            }
            HStack{
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                //Bottom Middle Square
                LittleSquare()
                LittleSquare()
                    .opacity(0)
                LittleSquare()
                    .opacity(0)
                }
            }
        }
    }
}

struct InventoryCharacterInfo_Previews: PreviewProvider {
    static var previews: some View {
        InventoryCharacterInfo()
    }
}
