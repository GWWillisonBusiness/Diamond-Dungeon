//
//  InventoryInfo.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 1/18/21.
//

import SwiftUI

struct InventoryInfo: View {
    @AppStorage ("ItemInventoryScreen") var ItemInventoryScreen = false
    
    @AppStorage ("IronSwordWeaponScreenActive") var IronSwordWeaponScreenActive = false
    @AppStorage ("IronSwordPurchase") var IronSwordPurchase = false
    
    @AppStorage ("FlameSpearWeaponScreenActive") var FlameSpearWeaponScreenActive = false
    @AppStorage ("FlameSpearPurchase") var FlameSpearPurchase = false
    @AppStorage ("FlameSpearScreen") var FlameSpearScreen = false
    @AppStorage ("MenuScreen") var FlameSpearMenuScreen = false
    @AppStorage ("FlameSpearEquipped") var FlameSpearEquipped = false
    
    var body: some View {
     ZStack {
        VStack {
            HStack {
                
                //Top Left #1
                ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                    if IronSwordPurchase == true {
                        Button(action: {
                       //Button Press Info
                           IronSwordWeaponScreenActive = true
                           
                        } ) {
                            ZStack {
                            Rectangle()
                            .foregroundColor(Color.gray)
                                .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(20)
                            Image("Sword.Iron")
                                .aspectRatio(contentMode: .fit)
                            }//ZStack
                        }// Button Shape and Size
                    }// If Statement
                }//ZStack
                
                //Top Middle #2
                ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                    if FlameSpearPurchase == true {
                        Button(action: {
                       //Button Press Info
                           FlameSpearWeaponScreenActive = true
                        } ) {
                            ZStack {
                            Rectangle()
                            .foregroundColor(Color.gray)
                                .aspectRatio(contentMode: .fit)
                            .edgesIgnoringSafeArea(.all)
                            .cornerRadius(20)
                            Image("Sword.FlameSpear")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            }//ZStack
                        }// Button Shape and Size
                    }// If Statement
                }//ZStack
                
                //Top Right #3
                        ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                        }
            }//HStack
            HStack {
                
                //Middle Left #4
                ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                }
                
                //Middle Middle #5
                    ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                    }
                
                //Middle Right #6
                        ZStack {
                Rectangle()
                .foregroundColor(Color.gray)
                    .aspectRatio(contentMode: .fit)
                .edgesIgnoringSafeArea(.all)
                .cornerRadius(20)
                        }
            }//HStack
            HStack {
            //Middle Left #4
            ZStack {
            Rectangle()
            .foregroundColor(Color.gray)
                .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
            .cornerRadius(20)
            }
            
            //Middle Middle #5
                ZStack {
            Rectangle()
            .foregroundColor(Color.gray)
                .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
            .cornerRadius(20)
                }
            
            //Middle Right #6
                    ZStack {
            Rectangle()
            .foregroundColor(Color.gray)
                .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
            .cornerRadius(20)
                    }
                }//HStack
            }//VStack
            if IronSwordWeaponScreenActive == true || FlameSpearWeaponScreenActive  == true {
                WeaponScreen()
            }
        }//ZStack
    }
}

struct InventoryInfo_Previews: PreviewProvider {
    static var previews: some View {
        InventoryInfo()
    }
}
