//
//  RandomNumber.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/3/20.
//

import SwiftUI

struct RandomNumber: View {
    
    @AppStorage ("randomTile") var randomTile = Int.random(in: 1..<4)
    
    var body: some View {
        
        if randomTile == 1 {
        TileSetTwo()
        }
        if randomTile == 2 {
            TileSetSix()
        }
        if randomTile == 3 {
            TileSetTwelve()
        }
    }
}

struct RandomNumber_Previews: PreviewProvider {
    static var previews: some View {
        RandomNumber()
    }
}
