//
//  CheckWallType.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/24/21.
//

import SwiftUI

struct CheckWallType: View {
    @AppStorage ("CheckTile") var CheckTile = 0
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    var body: some View {
        if CurrentDungeon == 1 {
        Image("Wall.Cobblestone")
            .resizable()
        .aspectRatio(contentMode: .fit)
        .edgesIgnoringSafeArea(.all)
                .cornerRadius(5)
        } else if CurrentDungeon == 2 {
            Image("Wall.SandCobblestone")
                .resizable()
            .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
                    .cornerRadius(5)
        } else if CurrentDungeon == 3 {
            Image("Wall.Water")
                .resizable()
            .aspectRatio(contentMode: .fit)
            .edgesIgnoringSafeArea(.all)
                    .cornerRadius(5)
        }
    }
}

struct CheckWallType_Previews: PreviewProvider {
    static var previews: some View {
        CheckWallType()
    }
}
