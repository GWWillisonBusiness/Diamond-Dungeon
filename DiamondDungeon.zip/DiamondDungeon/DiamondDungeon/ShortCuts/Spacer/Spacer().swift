//
//  Spacer().swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/26/20.
//

import SwiftUI

struct Spacer__: View {
    var body: some View {
        Spacer()
        Spacer()
    }
}

struct Spacer___Previews: PreviewProvider {
    static var previews: some View {
        Spacer__()
    }
}
