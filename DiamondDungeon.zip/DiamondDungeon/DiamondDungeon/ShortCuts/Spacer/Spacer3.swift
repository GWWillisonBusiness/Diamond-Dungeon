//
//  Spacer3.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/8/20.
//

import SwiftUI

struct Spacer3: View {
    var body: some View {
        Spacer()
        Spacer()
        Spacer()
    }
}

struct Spacer3_Previews: PreviewProvider {
    static var previews: some View {
        Spacer3()
    }
}
