//
//  TileBoardLocation.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/1/20.
//

import SwiftUI

struct TileBoardLocation: View {
    @AppStorage ("TutorialComplete") var TutorialComplete = false
    
    //Current Active Tile Set That is Active
    @AppStorage ("NorthActiveTileSet") var NorthActiveTileSet = 1
    @AppStorage ("EastActiveTileSet") var EastActiveTileSet = 1
    @AppStorage ("SouthActiveTileSet") var SouthActiveTileSet = 1
    @AppStorage ("WestActiveTileSet") var WestActiveTileSet = 1
    
    // Some of The Tiles At Which You Will Move Into
    @AppStorage ("ZeroZero") var ZeroZero = 0
    @AppStorage ("ZeroNOne") var ZeroNOne = 0
    @AppStorage ("ZeroNTwo") var ZeroNTwo = 0
    @AppStorage ("ZeroNThree") var ZeroNThree = 0
    @AppStorage ("ZeroPOne") var ZeroPOne = 0
    @AppStorage ("ZeroPTwo") var ZeroPTwo = 0
    @AppStorage ("ZeroPThree") var ZeroPThree = 0
    @AppStorage ("POneZero") var POneZero = 0
    @AppStorage ("PTwoZero") var PTwoZero = 0
    @AppStorage ("PThreeZero") var PThreeZero = 0
    @AppStorage ("POneNOne") var POneNOne = 0
    @AppStorage ("POneNOne") var NOnePOne = 0
    
    @AppStorage ("TileMapSelector") var TileMapSelector = 0
    
    @AppStorage ("NorthWall") var NorthWall = 0
    @AppStorage ("EastWall") var EastWall = 0
    @AppStorage ("SouthWall") var SouthWall = 0
    @AppStorage ("WestWall") var WestWall = 0
    
    @AppStorage ("Level") var Level = 1
    @AppStorage ("Character") var CharacterPlacement = 5
    
    //0 = False. 1 = True.
    @AppStorage ("LeftBoardEdge") var xBoardEdge = 0
    @AppStorage ("rightBoardEdge") var yBoardEdge = 0

    var body: some View {
        
        if TutorialComplete == true {
            
        
        //Spawn (X = 0 and Y = 0)
        if xBoardEdge == 0 && yBoardEdge == 0 {
            if SouthActiveTileSet != 8 {
            TileSetOne()
            } else {
                TileSetThirteen()
            }
        }
        //UP (From Y = 1 and Greater)
        if NorthActiveTileSet == 1 {
        if xBoardEdge == 0 && yBoardEdge == 1 {
            TileSetTwo()
        } else if xBoardEdge == 0 && yBoardEdge == 2 {
            TileSetNine()
        } else if xBoardEdge == 1 && yBoardEdge == 1 {
            TileSetTen()
        } else if xBoardEdge == 2 && yBoardEdge == 1 {
            TileSetEight()
        } else if xBoardEdge == 1 && yBoardEdge == 2 {
            TileSetFifteen()
        } else if xBoardEdge == -1 && yBoardEdge == 2 {
            TileSetNine()
        } else if xBoardEdge == -2 && yBoardEdge == 2 {
            TileSetTwelve()
        } else if xBoardEdge == -1 && yBoardEdge == 1 {
            TileSetNineteen()
        } 
        } else if NorthActiveTileSet == 2 {
            if xBoardEdge == 0 && yBoardEdge == 1 {
                TileSetSix()
            } else if xBoardEdge == 0 && yBoardEdge == 2 {
                TileSetEleven()
            } else if xBoardEdge == 1 && yBoardEdge == 1 {
                TileSetThree()
            } else if xBoardEdge == 1 && yBoardEdge == 2 {
                TileSetNine()
            } else if xBoardEdge == 2 && yBoardEdge == 2 {
                TileSetThree()
            }
        } else if NorthActiveTileSet == 3 {
            if xBoardEdge == 0 && yBoardEdge == 1 {
                TileSetSeventeen()
            } else if xBoardEdge == -1 && yBoardEdge == 1 {
                TileSetTen()
            } else if xBoardEdge == -2 && yBoardEdge == 1 {
                TileSetNineteen()
            } else if xBoardEdge == -1 && yBoardEdge == 2 {
                TileSetThirteen()
            } else if xBoardEdge == 0 && yBoardEdge == 2 {
                TileSetTwentyTwo()
            }
        } else if NorthActiveTileSet == 4 {
            if xBoardEdge == 0 && yBoardEdge == 1 {
                TileSetTwo()
            } else if xBoardEdge == 1 && yBoardEdge == 2 {
                TileSetThirteen()
            } else if xBoardEdge == 1 && yBoardEdge == 1 {
                TileSetFive()
            } else if xBoardEdge == -1 && yBoardEdge == 1 {
                TileSetNine()
            } else if xBoardEdge == -2 && yBoardEdge == 1 {
                TileSetNineteen()
            }
        } else if NorthActiveTileSet == 5 {
            if xBoardEdge == 0 && yBoardEdge == 1 {
                TileSetSix()
            } else if xBoardEdge == 0 && yBoardEdge == 2 {
                TileSetFifteen()
            } else if xBoardEdge == 0 && yBoardEdge == 3 {
                TileSetTwelve()
            } else if xBoardEdge == 1 && yBoardEdge == 1 {
                TileSetFive()
            } else if xBoardEdge == -1 && yBoardEdge == 2 {
                TileSetNineteen()
            } else if xBoardEdge == 1 && yBoardEdge == 2 {
                TileSetSix()
            } else if xBoardEdge == 1 && yBoardEdge == 3 {
                TileSetFifteen()
            }  else if xBoardEdge == 2 && yBoardEdge == 2 {
                TileSetThree()
            }
        } else if NorthActiveTileSet == 6 {
            if xBoardEdge == 0 && yBoardEdge == 1 {
                TileSetTwenty()
            } else if xBoardEdge == 0 && yBoardEdge == 2 {
                TileSetThirteen()
            }
        } else if NorthActiveTileSet == 7 {
            if xBoardEdge == 0 && yBoardEdge == 1 {
                TileSetSeventeen()
            } else if xBoardEdge == -1 && yBoardEdge == 1 {
                TileSetNineteen()
            } else if xBoardEdge == 0 && yBoardEdge == 2 {
                TileSetTwentyTwo()
            }
        }
        
        //Right (X = 1 and Greater)
        if EastActiveTileSet == 1 {
        if xBoardEdge == 1 && yBoardEdge == 0 {
            TileSetFourteen()
        } else if xBoardEdge == 2 && yBoardEdge == 0 {
            TileSetEight()
            }
        } else if EastActiveTileSet == 2 {
          if  xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 2 && yBoardEdge == 0 {
                TileSetEight()
            }
        } else if EastActiveTileSet == 3 {
            if xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 2 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 3 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 4 && yBoardEdge == 0 {
                TileSetTwo()
            } else if xBoardEdge == 5 && yBoardEdge == 0 {
                TileSetFive()
            } else if xBoardEdge == 4 && yBoardEdge == -1 {
                TileSetSeven()
            } else if xBoardEdge == 4 && yBoardEdge == 1 {
                TileSetTwelve()
            } else if xBoardEdge == 5 && yBoardEdge == 1 {
                TileSetFifteen()
            }
        } else if EastActiveTileSet == 4 {
            if xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 2 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 3 && yBoardEdge == 0 {
                TileSetThree()
            }
        } else if EastActiveTileSet == 5 {
            if xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetThree()
            }
        } else if EastActiveTileSet == 6 {
            if xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 2 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 3 && yBoardEdge == 0 {
                TileSetTen()
            } else if xBoardEdge == 4 && yBoardEdge == 0 {
                TileSetThree()
            } else if xBoardEdge == 3 && yBoardEdge == 1 {
                TileSetThirteen()
            }
        } else if EastActiveTileSet == 7 {
            if xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 2 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == 3 && yBoardEdge == 0 {
                TileSetTen()
            } else if xBoardEdge == 4 && yBoardEdge == 0 {
                TileSetThree()
            } else if xBoardEdge == 3 && yBoardEdge == 1 {
                TileSetTwenty()
            } else if xBoardEdge == 3 && yBoardEdge == 2 {
                TileSetTwenty()
            } else if xBoardEdge == 3 && yBoardEdge == 3 {
                TileSetSix()
            } else if xBoardEdge == 3 && yBoardEdge == 4 {
                TileSetSeventeen()
            } else if xBoardEdge == 2 && yBoardEdge == 4 {
                TileSetTwelve()
            } else if xBoardEdge == 4 && yBoardEdge == 3 {
                TileSetThree()
            } else if xBoardEdge == 3 && yBoardEdge == 5 {
                TileSetTwentyTwo()
            }
        }
        //Left (X = -1 and Lower)
        if WestActiveTileSet == 1 {
        if xBoardEdge == -1 && yBoardEdge == 0 {
            TileSetFourteen()
        } else if xBoardEdge == -2 && yBoardEdge == 0 {
            TileSetEleven()
        } else if xBoardEdge == -2 && yBoardEdge == -1 {
            TileSetSeven()
            }
        } else if WestActiveTileSet == 2 {
            if xBoardEdge == -1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == -2 && yBoardEdge == 0 {
                TileSetFourteen()
            } else if xBoardEdge == -3 && yBoardEdge == 0 {
                TileSetSix()
            } else if xBoardEdge == -2 && yBoardEdge == -1 {
                TileSetThree()
            } else if xBoardEdge == -3 && yBoardEdge == -1 {
                TileSetEightteen()
            } else if xBoardEdge == -3 && yBoardEdge == 1 {
                TileSetSeventeen()
            } else if xBoardEdge == -4 && yBoardEdge == 1 {
                TileSetTwelve()
            } else if xBoardEdge == -3 && yBoardEdge == 2 {
                TileSetTwentyTwo()
            }
        } else if WestActiveTileSet == 3 {
            if xBoardEdge == -1 && yBoardEdge == 0 {
                TileSetNineteen()
            }
        } else if WestActiveTileSet == 4 {
            if xBoardEdge == -1 && yBoardEdge == 0 {
                TileSetNineteen()
            }
        } else if WestActiveTileSet == 5 {
            if xBoardEdge == -1 && yBoardEdge == 0 {
                TileSetFourteen()
            } else if xBoardEdge == -2 && yBoardEdge == 0 {
                TileSetEleven()
            } else if xBoardEdge == -2 && yBoardEdge == -1 {
                TileSetSeven()
            }
        } else if WestActiveTileSet == 6 {
            if xBoardEdge == -1 && yBoardEdge == 0 {
                TileSetNine()
            } else if xBoardEdge == -2 && yBoardEdge == 0 {
                TileSetTwelve()
            }
        } else if WestActiveTileSet == 7 {
            if xBoardEdge == -1 && yBoardEdge == 0 {
                TileSetFourteen()
            } else if xBoardEdge == -2 && yBoardEdge == 0 {
                TileSetNineteen()
            }
        }
        //Down ( Y = -1 and Lower)
        if SouthActiveTileSet == 1 {
        if xBoardEdge == 0 && yBoardEdge == -1 {
            TileSetTen()
        } else if xBoardEdge == 0 && yBoardEdge == -2 {
            TileSetThree()
        } else if xBoardEdge == -1 && yBoardEdge == -1 {
            TileSetEleven()
        } else if xBoardEdge == 1 && yBoardEdge == -1 {
            TileSetNine()
        } else if xBoardEdge == 2 && yBoardEdge == -1 {
            TileSetNine()
        } else if xBoardEdge == 3 && yBoardEdge == -1 {
            TileSetThree()
        } else if xBoardEdge == -1 && yBoardEdge == -2 {
            TileSetEightteen()
            }
        } else if SouthActiveTileSet == 2 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetSix()
            } else if xBoardEdge == 0 && yBoardEdge == -2 {
                TileSetSeven()
            } else if xBoardEdge == 1 && yBoardEdge == -1 {
                TileSetFour()
            } else if xBoardEdge == 1 && yBoardEdge == -2 {
                TileSetEightteen()
            } else if xBoardEdge == 2 && yBoardEdge == -1 {
                TileSetThree()
            } else if xBoardEdge == 2 && yBoardEdge == -2 {
                TileSetFifteen()
            } else if xBoardEdge == 2 && yBoardEdge == -3 {
                TileSetSixteen()
            }
        } else if SouthActiveTileSet == 3 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetSix()
            } else if xBoardEdge == 0 && yBoardEdge == -2 {
                TileSetSeven()
            } else if xBoardEdge == 1 && yBoardEdge == -1 {
                TileSetEight()
            }
        } else if SouthActiveTileSet == 4 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetSix()
            } else if xBoardEdge == 0 && yBoardEdge == -2 {
                TileSetEightteen()
            } else if xBoardEdge == 0 && yBoardEdge == -3 {
                TileSetNine()
            } else if xBoardEdge == 1 && yBoardEdge == -1 {
                TileSetThree()
            } else if xBoardEdge == 1 && yBoardEdge == -2 {
                TileSetFifteen()
            } else if xBoardEdge == -1 && yBoardEdge == -3 {
                TileSetTwelve()
            } else if xBoardEdge == 1 && yBoardEdge == -3 {
                TileSetFive()
            }
        } else if SouthActiveTileSet == 5 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetFive()
            } else if xBoardEdge == 0 && yBoardEdge == -2 {
                TileSetNine()
            } else if xBoardEdge == -1 && yBoardEdge == -1 {
                TileSetEleven()
            } else if xBoardEdge == -1 && yBoardEdge == -2 {
                TileSetEightteen()
            } else if xBoardEdge == 1 && yBoardEdge == -2 {
                TileSetThree()
            }
        } else if SouthActiveTileSet == 6 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetTwenty()
            } else if xBoardEdge == 0 && yBoardEdge == -2 {
                TileSetSeven()
            }
        } else if SouthActiveTileSet == 7 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetSeven()
            }
        } else if SouthActiveTileSet == 8 {
            if xBoardEdge == 0 && yBoardEdge == -1 {
                TileSetTwentyOne()
            }
          }
        } else if TutorialComplete == false {
            if xBoardEdge == 0 && yBoardEdge == 0 {
                TileSetTwentyThree()
            } else if xBoardEdge == 1 && yBoardEdge == 0 {
                TileSetTwentyFour()
            } else if xBoardEdge == 2 && yBoardEdge == 0 {
                TileSetTwentyFive()
            } else if xBoardEdge == 3 && yBoardEdge == 0 {
                TileSetTwentySix()
            } else if xBoardEdge == 1 && yBoardEdge == 1 {
                TileSetTwentyTwo()
            }
        }
    }
}

struct TileBoardLocation_Previews: PreviewProvider {
    static var previews: some View {
        TileBoardLocation()
    }
}
