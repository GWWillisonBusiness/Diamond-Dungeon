//
//  EnemyChosen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/8/20.
//

import SwiftUI

struct EnemyChosen: View {
    
    @AppStorage ("MaxHeroHealth") var MaxHeroHealth = 8
    @AppStorage ("CurrentHeroHealth") var CurrentHeroHealth = 8
    @AppStorage ("CurrentHeroAttack") var CurrentHeroAttack = 3
    
    @AppStorage ("CurrentEnemyHealth") var CurrentEnemyHealth = 4
    @AppStorage ("CurrentHeroAttack") var CurrentEnemyAttack = 1

    @AppStorage ("EC") var EnemyChosen = Int.random(in: 0..<4)
    var body: some View {
        Text("")
    }
}

struct EnemyChosen_Previews: PreviewProvider {
    static var previews: some View {
        EnemyChosen()
    }
}
