//
//  CheckFloorEnemy.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 3/25/21.
//

import SwiftUI

struct CheckFloorEnemy: View {
    
    @AppStorage ("CheckTile") var CheckTile = 0
    
    //Which Dungeon is the Player in
    @AppStorage ("CurrentDungeon") var CurrentDungeon = 1
    
    var body: some View {
        if CurrentDungeon == 1 {
            if CheckTile == 1 || CheckTile == 2 {
        Image("Floor.Sand")
        .resizable()
            .foregroundColor(Color.white)
            .frame(width: 2000, height: 2000)
            } else if CheckTile == 3 {
                Image("Floor.Grass")
                .resizable()
                    .foregroundColor(Color.white)
                    .frame(width: 2000, height: 2000)
            }
        } else if CurrentDungeon == 2 {
            Image("Floor.Sand2")
            .resizable()
                .foregroundColor(Color.white)
                .frame(width: 2000, height: 2000)
        } else if CurrentDungeon == 3 {
            Image("Floor.Seaweed")
            .resizable()
                .foregroundColor(Color.white)
                .frame(width: 2000, height: 2000)
        }
    }
}

struct CheckFloorEnemy_Previews: PreviewProvider {
    static var previews: some View {
        CheckFloorEnemy()
    }
}
