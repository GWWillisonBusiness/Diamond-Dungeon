//
//  ActiveScreen.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 11/1/20.
//

import SwiftUI

struct ActiveScreen: View {
    // 1 = Homescreen, 2 = Shop, 3 = Inventory, 4 = Clans, 5 = Skills, 6 = Dungeon, 7 = Win Screen, 8 = Lost Screen, 9 = Battle Screen, 12 = Enemy Defeated, 13 = Hero Defeated
    @AppStorage ("CurrentScreen") var CurrentScreen = 1
    @AppStorage ("TutorialComplete") var TutorialComplete = false
    
    var body: some View {
        ZStack{
        if CurrentScreen == 1 {
            Homescreen()
        } else if CurrentScreen == 2 {
            Shop()
        } else if CurrentScreen == 3 {
            Inventory()
        } else if CurrentScreen == 4 {
            Clans()
        } else if CurrentScreen == 5 {
            Skills()
        } else if CurrentScreen == 6 {
            Play()            
        } else if CurrentScreen == 7 {
            TileSetTwelve()
        } else if CurrentScreen == 9 {
            FightInBattle()
        } else if CurrentScreen == 12 {
            EnemyDefeated()
        } else if CurrentScreen == 13 {
            Gameover()
        } else if CurrentScreen == 14 {
            ItemsMenu()
        } else if CurrentScreen == 15 {
            //Once "Play" Has Been Hit
            InGameInventory()
        } else if CurrentScreen == 16 {
            TreasureChest()
            }
        }
    }
}

struct ActiveScreen_Previews: PreviewProvider {
    static var previews: some View {
        ActiveScreen()
    }
}
