//
//  Spacer.swift
//  DiamondDungeon
//
//  Created by Grant Willison on 10/26/20.
//

import SwiftUI

struct Spacer: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Spacer_Previews: PreviewProvider {
    static var previews: some View {
        Spacer()
    }
}
